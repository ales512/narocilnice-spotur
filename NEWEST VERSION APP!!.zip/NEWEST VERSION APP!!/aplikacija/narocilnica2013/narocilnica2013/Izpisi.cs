﻿namespace narocilnica2013
{


    partial class Izpisi
    {
        partial class izpisiDataTable
        {
        }
    }
}
