﻿namespace narocilnica2013
{
    public class Podjetja
    {
        private string _Podjetje;

        public string Podjetje
        {
            get { return _Podjetje; }
            set { _Podjetje = value; }
        }
        private string _naslov;

        public string Naslov
        {
            get { return _naslov; }
            set { _naslov = value; }
        }

        private string _Kraj;

        public string Kraj
        {
            get { return _Kraj; }
            set { _Kraj = value; }
        }
    }
}