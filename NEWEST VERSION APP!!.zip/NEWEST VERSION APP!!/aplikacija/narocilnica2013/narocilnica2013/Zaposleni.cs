﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace narocilnica2013
{
    public class Zaposleni
    {
        private string _ImePriimek;

        public string ImePriimek
        {
            get { return _ImePriimek; }
            set { _ImePriimek = value; }
        }
        private string _GSM;

        public string GSM
        {
            get { return _GSM; }
            set { _GSM = value; }
        }

        private string _Naziv;

        public string Naziv
        {
            get { return _Naziv; }
            set { _Naziv = value; }
        }
    }
}
