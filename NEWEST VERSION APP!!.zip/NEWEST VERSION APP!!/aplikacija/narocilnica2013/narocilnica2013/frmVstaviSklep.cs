﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class frmVstaviSklep : Form
    {

        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");

        public frmVstaviSklep()
        {
            InitializeComponent();
           
        }
     
        private bool KontrolaVnosnihPolj()
        {

             if (St_sklepa.Text == string.Empty)
            {
                MessageBox.Show("Stevilka sklepa je obvezen");
                return false;
            }
            else if (St_spisa.Text == string.Empty)
            {
                MessageBox.Show("Stevilka spisa je obvezen");
                return false;
            }
          
            else if (Pred_naroc.Text == string.Empty)
            {
                MessageBox.Show("Predmet narocila je obvezen");
                return false;
            }
            else if (opred_post_kont.Text == string.Empty)
            {
                MessageBox.Show("Opredelitev postavke - konta je obvezen");
                return false;
            }
            else if (cbxOdgOs.SelectedItem == null)
            {
                MessageBox.Show("Odgovorna oseba je obvezen");
                return false;
            }
            else if (cbxIzvPo.SelectedItem == null)
            {
                MessageBox.Show("Izvajanje po je obvezen");
                return false;
            }

            else if (cbxPrip.SelectedItem == null)
            {
                MessageBox.Show("Pripravil-a je obvezen");
                return false;
            }
            else if (cbxZap.SelectedItem == null)
            {
                MessageBox.Show("Zaposleni je obvezen");
                return false;
            }

            else if (oc_vr.Text == string.Empty)
            {
                MessageBox.Show("Ocenjena vrednost je obvezen");
                return false;
            }
           
            else
            {
                return true;
            }
        }
        void PodatkiComboBoxOdgovornaOseba()
        {


            string poizvedba = "select * from dbo.Zaposleni";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                  
                    string zap = r["ImePriimek"].ToString();
                    cbxZap.Items.Add(zap);
                    cbxOdgOs.Items.Add(zap);
                    cbxPrip.Items.Add(zap);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        void PodatkiComboBoxIzvajanje()
        {


            string poizvedba = "select * from dbo.sklep_postopek";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string zap = r["Polje1"].ToString();
                 
                    cbxIzvPo.Items.Add(zap);
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        private void frmVstaviSklep_Load(object sender, EventArgs e)
        {
            PodatkiComboBoxOdgovornaOseba();
            PodatkiComboBoxIzvajanje();

            cbxIzvPo.SelectedIndex = 0;
            cbxOdgOs.SelectedIndex = 0;
            cbxPrip.SelectedIndex = 0;
            cbxZap.SelectedIndex = 0;
           
        }

        private void btnDodaj_text(object sender, EventArgs e)
        {
              
                if (KontrolaVnosnihPolj() == true)
                {
               
                    string insertQuery =
                        "INSERT INTO dbo.vsiSklepi (St_sklepa, Stevilka_spisa, Pred_naroc, ocenjena_vrednost, Opredelitev_postavke_konta, Odgovorna_oseba, Izvajanje_po, Pripravil_a, Zaposleni, Direktorica, Datum)VALUES('" +
                        St_sklepa.Text + "','" + St_spisa.Text + "','" +
                        Pred_naroc.Text + "', '" + oc_vr.Text + "', '" + opred_post_kont.Text + "', '" + cbxOdgOs.Text +
                        "', '" + cbxIzvPo.Text + "', '" + cbxPrip.Text + "', '" + cbxZap.Text + "', '" +
                        "Marija Lah" + "', '" + dtpDatum.Value.ToString("yyyy-MM-dd") + "')"; //month more bit MM ne mm, ker mm predstavlja minute
                connection.Open();
                    SqlCommand command = new SqlCommand(insertQuery, connection);

                    try
                    {
                        if (command.ExecuteNonQuery() == 1)
                        {
                      

                        DialogResult = DialogResult.OK;


                        }
                        else
                        {
                            MessageBox.Show("Podatki niso vneseni...");
                        }

               
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        connection.Close();
                    }
                }
        }

        private void btnPreklici_text(object sender, EventArgs e)
        {
            this.Close();
          
        }


        private void btnPonastavi_click(object sender, EventArgs e)
        {

            St_sklepa.Text = String.Empty;

            St_spisa.Text = String.Empty;
            Pred_naroc.Text = String.Empty;
            oc_vr.Text = String.Empty;
            opred_post_kont.Text = String.Empty;

        }

        private void oc_vr_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(oc_vr.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                oc_vr.Text = oc_vr.Text.Remove(oc_vr.Text.Length - 1);
            }
        }
    }
}
