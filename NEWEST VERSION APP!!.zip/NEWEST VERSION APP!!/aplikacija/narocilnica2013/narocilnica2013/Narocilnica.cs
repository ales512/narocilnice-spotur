﻿using System;

namespace narocilnica2013
{


    public class Narocilnica
    {
        private string _St_narocilnice;

        public string St_Narocilnice
        {
            get { return _St_narocilnice; }
            set { _St_narocilnice = value; }
        }
        private string _Podjetje;

        public string Podjetje
        {
            get { return _Podjetje; }
            set { _Podjetje = value; }
        }

        private string _Naslov;

        public string naslov
        {
            get { return _Naslov; }
            set { _Naslov = value; }
        }

        private string _Kraj;

        public string Kraj
        {
            get { return _Kraj; }
            set { _Kraj = value; }
        }

        private string _VrstaNarocila;

        public string VrstaNarocila
        {
            get { return _VrstaNarocila; }
            set { _VrstaNarocila = value; }
        }


        private string _Postavka;

        public string Postavka
        {
            get { return _Postavka; }
            set { _Postavka = value; }
        }


        private string _PredmetNarocilnice;

        public string PredmetNarocilnice
        {
            get { return _PredmetNarocilnice; }
            set { _PredmetNarocilnice = value; }
        }

        private string _KolicinaEna;

        public string kolicina1
        {
            get { return _KolicinaEna; }
            set { _KolicinaEna = value; }
        }
        private string _ME;

        public string ME
        {
            get { return _ME; }
            set { _ME = value; }
        }

        private string _Povezava;

        public string Povezava
        {
            get { return _Povezava; }
            set { _Povezava = value; }
        }

        private string _NetoVrednost;

        public string NetoVrednost
        {
           
            get { return _NetoVrednost; }

            set
            {
               
                _NetoVrednost = value;

            }
        }
    
        
        private string _BrutoVrednost;

        public string BrutoVrednost
        {
            get { return _BrutoVrednost; }
      
            set
            {
              
                _BrutoVrednost = value;
               
            }
        }
        private string _PredmetNarocilniceDva;

        private string _DDV;

        public string DDV
        {
            get { return _DDV; }
            set { _DDV = value; }
        }
        private string _VrednostDDV;
        
        public string VrednostDDV
        {
            get { return _VrednostDDV; }

            set
            {
               
                _VrednostDDV = value;

            }
        
        }
        public string PredmetNarocilnice2
        {
            get { return _PredmetNarocilniceDva; }
            set { _PredmetNarocilniceDva = value; }
        }
        public string _KolicinaDva;
        public string Kolicina2
        {
            get { return _KolicinaDva; }
            set { _KolicinaDva = value; }
        }
        private string _MEdva;

        public string ME2
        {
            get { return _MEdva; }
            set { _MEdva = value; }
        }
        private string _NetoVrednostdva;

        public string NetoVrednost2
        {
            get { return _NetoVrednostdva; }
       
            set
            {
                _NetoVrednostdva = value;
                
            }
        }

        private string _BrutoVrednostdva;

        public string BrutoVrednost2
        {
            get { return _BrutoVrednostdva; }
  
            set
            {
                _BrutoVrednostdva = value;
                
            }
        }

        private string _VrednostDDV2;

        public string VrednostDDV2
        {
            get { return _VrednostDDV2; }

            set
            {
                _VrednostDDV2 = value;
                
            }

        }

        private string _KontaktnaOseba;

        public string KontaktnaOseba
        {
            get { return _KontaktnaOseba; }
            set { _KontaktnaOseba = value; }
        }

        private string _STRmesto;

        public string STR_mesto
        {
            get { return _STRmesto; }
            set { _STRmesto = value; }
        }

        private string _Oddano;

        public string Oddano
        {
            get { return _Oddano; }
            set { _Oddano = value; }
        }

        private DateTime _datumNarocilnice;

        public DateTime datumNarocilnice
        {
            get { return _datumNarocilnice; }
            set { _datumNarocilnice = value; }
        }

        private DateTime? _RokDobave;

        public DateTime? RokDobave
        {
            get { return _RokDobave; }
            set { _RokDobave = value; }
        }

        private int _TelefonskaSt;

        public int TelefonskaSt
        {
            get { return _TelefonskaSt; }
            set { _TelefonskaSt = value;  }
        }

        private string _Naziv;

        public string Naziv 
        {
            get { return _Naziv; }
            set { _Naziv = value; }
        }

     
    }
}