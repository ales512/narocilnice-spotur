﻿using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class frmPodjetja : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");

        private frmVstaviNarocilnice nar;
        List<Podjetja> _dobaviteljiDefault = new List<Podjetja>();
        List<Podjetja> _dobaviteljiFiltrirani = new List<Podjetja>();


    
        public frmPodjetja(frmVstaviNarocilnice r)
        {
            nar = r;
            InitializeComponent();
        }
      

        private void frmPodjetja_Load(object sender, EventArgs e)
        {
            string valueToSearch = txtNaziv.Text.ToString();
            searchData(valueToSearch);
        }

        private void searchData(string valueToSearch)
        {

            string query = "SELECT Podjetje, naslov, Kraj FROM dbo.Dobavitelji WHERE Podjetje like '%" + valueToSearch + "%' OR naslov like '%" + valueToSearch + "%' OR Kraj like '%" + valueToSearch + "%'";



            _dobaviteljiDefault = connection.Query<Podjetja>(query, commandType: CommandType.Text).ToList();

            podjetjaBindingSource.DataSource = _dobaviteljiDefault;

            _dobaviteljiFiltrirani = _dobaviteljiDefault; 
        }

       

        private void btnPonastavi_click(object sender, EventArgs e)
        {
            txtNaziv.Text = string.Empty;
            txtNaslov.Text = string.Empty;
            txtKraj.Text = string.Empty;

            string valueToSearch = txtNaziv.Text.ToString();
            searchData(valueToSearch);
        }

        private void btnDodajVvstaviNove_click(object sender, EventArgs e)
        {
            frmVstaviNarocilnice f = new frmVstaviNarocilnice();
            
            f.Podjetje.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            f.Naslov.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            f.Kraj.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            f.Show();
            this.Close();

        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            frmVstaviNarocilnice f = new frmVstaviNarocilnice();

            //Če ni nič zapisov v šifrantu, ne moreš nič izbrati (potem z obvestilom obvestiš uporabnika, da ni nič zapisov). 
            if (dataGridView1.CurrentRow != null)
            {
                f.Podjetje.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
                f.Naslov.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
                f.Kraj.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
                f.ShowDialog();
   
            }
            else
            {
                MessageBox.Show("Ni bila izbrana nobena vrstica.");
            }
        }

        private void IsciPodjetje(int status, string filterNazivPodjetja, string filterNaslovPodjetja, string filterKrajPodjetja)
        {

            string nazivPodjetja = string.Empty; //string nazivPodjetja = ""; 
            string naslovPodjetja = string.Empty; //string naslovPodjetja = ""; 
            string krajPodjetja = string.Empty; //string krajPodjetja = ""; 

            nazivPodjetja = filterNazivPodjetja;
            naslovPodjetja = filterNaslovPodjetja;
            krajPodjetja = filterKrajPodjetja;


            //S pomočjo LINQ filtriramo zapise v seznamu. 
            //Seznam _dobaviteljiDefault ima shranjene vse zapise, ki smo jih pridobili iz baze
            //Seznam _dobaviteljiFiltrirani ima shranjene samo zapise, ki jih sfiltriramo
            var x = (from item in _dobaviteljiDefault
                     where item.Podjetje.Contains(nazivPodjetja) && item.Naslov.Contains(naslovPodjetja) && item.Kraj.Contains(krajPodjetja)
                     select item).ToList();

            //Filtirane zapise, ki jih dobimo z LINQujem in jih shranimo v spremenljivko x, shranimo v naš seznam, to je spremenljivka _dobaviteljiFiltrirani
            _dobaviteljiFiltrirani = x;

            //Filtrirane zapise, ki jih imamo v spremenljivki _dobaviteljiFiltrirani izpišemo v tabeli (na zaslon) preko binding source-a.
            podjetjaBindingSource.DataSource = _dobaviteljiFiltrirani;
        }

        private void txtNaziv_KeyUp(object sender, KeyEventArgs e)
        {
            string nazivPodjetja = string.Empty;
            string naslovPodjetja = string.Empty;
            string krajPodjetja = string.Empty;

            nazivPodjetja = txtNaziv.Text;
            naslovPodjetja = txtNaslov.Text;
            krajPodjetja = txtKraj.Text; 

            //Če je v iskalnem polju kar koli, potem pokliči metodo IsciPodjetje(...) 
            if (nazivPodjetja.Length > 0)
            {
                IsciPodjetje(1, nazivPodjetja, naslovPodjetja, krajPodjetja);
            }
            //Če ni nič v iskalnem polju, preveri ali so vsa polja prazna
            else
            {
                //Preveri ali so vsa iskalna polja prazna
                if (txtNaziv.Text == string.Empty && txtNaslov.Text == string.Empty && txtKraj.Text == string.Empty)
                {
                    podjetjaBindingSource.DataSource = _dobaviteljiDefault; 
                }
                //Će niso vsa iskalna polja prazna išči po tistih iskalnih poljih, ki so vnesena
                else
                {
                    IsciPodjetje(1, nazivPodjetja, naslovPodjetja, krajPodjetja);
                }
            }
        }

        private void txtNaslov_KeyUp(object sender, KeyEventArgs e)
        {
            string nazivPodjetja = string.Empty;
            string naslovPodjetja = string.Empty;
            string krajPodjetja = string.Empty;

            nazivPodjetja = txtNaziv.Text;
            naslovPodjetja = txtNaslov.Text;
            krajPodjetja = txtKraj.Text;

            //Če je v iskalnem polju kar koli, potem pokliči metodo IsciPodjetje(...) 
            if (naslovPodjetja.Length > 0)
            {
                IsciPodjetje(2, nazivPodjetja, naslovPodjetja, krajPodjetja);
            }
            //Če ni nič v iskalnem polju, preveri ali so vsa polja prazna
            else
            {
                //Preveri ali so vsa iskalna polja prazna
                if (txtNaziv.Text == string.Empty && txtNaslov.Text == string.Empty && txtKraj.Text == string.Empty)
                {
                    podjetjaBindingSource.DataSource = _dobaviteljiDefault;
                }
                //Će niso vsa iskalna polja prazna išči po tistih iskalnih poljih, ki so vnesena
                else
                {
                    IsciPodjetje(2, nazivPodjetja, naslovPodjetja, krajPodjetja);
                }
            }
        }

        private void txtKraj_KeyUp(object sender, KeyEventArgs e)
        {
            string nazivPodjetja = string.Empty;
            string naslovPodjetja = string.Empty;
            string krajPodjetja = string.Empty;

            nazivPodjetja = txtNaziv.Text;
            naslovPodjetja = txtNaslov.Text;
            krajPodjetja = txtKraj.Text;

            //Če je v iskalnem polju kar koli, potem pokliči metodo IsciPodjetje(...) 
            if (krajPodjetja.Length > 0)
            {
                IsciPodjetje(3, nazivPodjetja, naslovPodjetja, krajPodjetja);
            }
            //Če ni nič v iskalnem polju, preveri ali so vsa polja prazna
            else
            {
                //Preveri ali so vsa iskalna polja prazna
                if (txtNaziv.Text == string.Empty && txtNaslov.Text == string.Empty && txtKraj.Text == string.Empty)
                {
                    podjetjaBindingSource.DataSource = _dobaviteljiDefault;
                }
                //Će niso vsa iskalna polja prazna išči po tistih iskalnih poljih, ki so vnesena
                else
                {
                    IsciPodjetje(3, nazivPodjetja, naslovPodjetja, krajPodjetja);
                }
            }
        }

    
        private void btnPreklici_click(object sender, EventArgs e)
        {
            this.Close();
       
        }

  
    }
}
