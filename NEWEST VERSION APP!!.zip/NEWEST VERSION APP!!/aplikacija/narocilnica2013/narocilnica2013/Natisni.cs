﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class Natisni : Form
    {

        private void NapolniReport2019()
        {
            Narocilnica2019BindingSource.DataSource = u;

            Microsoft.Reporting.WinForms.ReportParameter[] p = new Microsoft.Reporting.WinForms.ReportParameter[]
            {

                new Microsoft.Reporting.WinForms.ReportParameter("St_narocilnice", u.St_Narocilnice),
                new Microsoft.Reporting.WinForms.ReportParameter("Podjetje", u.Podjetje),
                new Microsoft.Reporting.WinForms.ReportParameter("naslov", u.naslov),
                new Microsoft.Reporting.WinForms.ReportParameter("Kraj", u.Kraj),
                new Microsoft.Reporting.WinForms.ReportParameter("VrstaNarocila", u.VrstaNarocila),
                new Microsoft.Reporting.WinForms.ReportParameter("Postavka", u.Postavka),
                new Microsoft.Reporting.WinForms.ReportParameter("PredmetNarocilnice", u.PredmetNarocilnice),
                new Microsoft.Reporting.WinForms.ReportParameter("kolicina1", u.kolicina1),
                new Microsoft.Reporting.WinForms.ReportParameter("ME", u.ME),
                new Microsoft.Reporting.WinForms.ReportParameter("Povezava", u.Povezava),
                new Microsoft.Reporting.WinForms.ReportParameter("NetoVrednost", u.NetoVrednost),
                new Microsoft.Reporting.WinForms.ReportParameter("BrutoVrednost", u.BrutoVrednost),
                new Microsoft.Reporting.WinForms.ReportParameter("PredmetNarocilnice2", u.PredmetNarocilnice2),
                new Microsoft.Reporting.WinForms.ReportParameter("Kolicina2", u.Kolicina2),
                new Microsoft.Reporting.WinForms.ReportParameter("ME2", u.ME2),
                new Microsoft.Reporting.WinForms.ReportParameter("NetoVrednost2", u.NetoVrednost2),
                new Microsoft.Reporting.WinForms.ReportParameter("BrutoVrednost2", u.BrutoVrednost2),
                new Microsoft.Reporting.WinForms.ReportParameter("KontaktnaOseba", u.KontaktnaOseba),
                new Microsoft.Reporting.WinForms.ReportParameter("STR_mesto", u.STR_mesto),
                new Microsoft.Reporting.WinForms.ReportParameter("Oddano", u.Oddano),
                new Microsoft.Reporting.WinForms.ReportParameter("DDV", u.DDV),
                new Microsoft.Reporting.WinForms.ReportParameter("VrednostDDV", u.VrednostDDV),
                new Microsoft.Reporting.WinForms.ReportParameter("datumNarocilnice", u.datumNarocilnice.ToString("dd/MM/yyyy")),
                new Microsoft.Reporting.WinForms.ReportParameter("Rokdobave", u.RokDobave?.ToShortDateString()),
      
        };
            this.reportViewer1.LocalReport.SetParameters(p);
            //this.reportViewer1.RefreshReport();

            this.reportViewer1.RefreshReport();
        }

        public Narocilnica u;

        public Natisni(Narocilnica f)
        {
            InitializeComponent();
            f = new Narocilnica();
            f = u;
        }
    
        private void NatisniTri_Load(object sender, EventArgs e)
        {// KontaktnaOseba, TelefonskaSt, Naziv--- podatki so izbrisani, saj gre za osebne podatke podjetja
      
            if (u.KontaktnaOseba == ")
            {

                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                     new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ",")
                };

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                     new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ",")
                     
                };

            
                this.reportViewer1.LocalReport.SetParameters(parameter);
           

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ","),
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
           

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                            new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ",")

                };


                this.reportViewer1.LocalReport.SetParameters(parameter);

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                              new Microsoft.Reporting.WinForms.ReportParameter("Naziv", "")
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
        

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ""),
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
            

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == ")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", "),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", "")
                    
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
           

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                       new Microsoft.Reporting.WinForms.ReportParameter("Naziv", "")
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
         
                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", "),
                     new Microsoft.Reporting.WinForms.ReportParameter("Naziv", "")
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
              

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    
                       
                };
                u.KontaktnaOseba = "";

                this.reportViewer1.LocalReport.SetParameters(parameter);
             

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ",")
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
                //this.reportViewer1.RefreshReport();

                this.reportViewer1.RefreshReport();

            }
            if (u.KontaktnaOseba == "Mateja Tajnšek")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", "") // prej je bil naziv referent za socialne zadeve
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
          

                this.reportViewer1.RefreshReport();
               
            }
            if (u.KontaktnaOseba == "Vesna Podpečan")
            {
                Microsoft.Reporting.WinForms.ReportParameter[] parameter = new Microsoft.Reporting.WinForms.ReportParameter[]
                {
                    new Microsoft.Reporting.WinForms.ReportParameter("TelefonskaSt", ""),
                    new Microsoft.Reporting.WinForms.ReportParameter("Naziv", ")
                };


                this.reportViewer1.LocalReport.SetParameters(parameter);
            

                this.reportViewer1.RefreshReport();
            
            }
     
            if (u.kolicina1 == null)
            {
                u.kolicina1 = " ";
            }
            if (u.ME == null)
            {
                u.ME = " ";
            }
            if (u.KontaktnaOseba == null)
            {
                u.KontaktnaOseba = " ";
            }
            if (u.Povezava == null)
            {
                u.Povezava = " ";
            }
            if (u.PredmetNarocilnice2 == null)
            {
                u.PredmetNarocilnice2 = " ";
            }
            if (u.Kolicina2 == null)
            {
                u.Kolicina2 = " ";
            }

            if (u.ME2 == null)
            {
                u.ME2 = " ";
            }

           
            if (u.VrstaNarocila == null)
            {
                u.VrstaNarocila = " ";
            }
          
          
            if (u.RokDobave == null)
            {
                Nullable<DateTime> nullDateTime = null;
               if(nullDateTime == null)
                {
                    u.RokDobave = (DateTime?)nullDateTime;
                    
                }

            }
          

            NapolniReport2019();
        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
