﻿
namespace narocilnica2013
{
    partial class frmVstaviSklep
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Pred_naroc = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.izvajanje_po = new System.Windows.Forms.Label();
            this.Stevilka_spisa = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.St_sklepa = new System.Windows.Forms.TextBox();
            this.opred_post_kont = new System.Windows.Forms.TextBox();
            this.St_spisa = new System.Windows.Forms.TextBox();
            this.cbxPrip = new System.Windows.Forms.ComboBox();
            this.cbxIzvPo = new System.Windows.Forms.ComboBox();
            this.cbxOdgOs = new System.Windows.Forms.ComboBox();
            this.cbxZap = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.oc_vr = new System.Windows.Forms.TextBox();
            this.dtpDatum = new System.Windows.Forms.DateTimePicker();
            this.button1 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Pred_naroc
            // 
            this.Pred_naroc.Location = new System.Drawing.Point(209, 172);
            this.Pred_naroc.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Pred_naroc.Name = "Pred_naroc";
            this.Pred_naroc.Size = new System.Drawing.Size(205, 22);
            this.Pred_naroc.TabIndex = 4;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(79, 236);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(115, 16);
            this.label25.TabIndex = 627;
            this.label25.Text = "odgovorna oseba";
            // 
            // izvajanje_po
            // 
            this.izvajanje_po.AutoSize = true;
            this.izvajanje_po.Location = new System.Drawing.Point(117, 270);
            this.izvajanje_po.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.izvajanje_po.Name = "izvajanje_po";
            this.izvajanje_po.Size = new System.Drawing.Size(79, 16);
            this.izvajanje_po.TabIndex = 626;
            this.izvajanje_po.Text = "izvajanje po";
            // 
            // Stevilka_spisa
            // 
            this.Stevilka_spisa.AutoSize = true;
            this.Stevilka_spisa.Location = new System.Drawing.Point(101, 116);
            this.Stevilka_spisa.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Stevilka_spisa.Name = "Stevilka_spisa";
            this.Stevilka_spisa.Size = new System.Drawing.Size(95, 16);
            this.Stevilka_spisa.TabIndex = 601;
            this.Stevilka_spisa.Text = "Številka_spisa";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(153, 148);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 16);
            this.label16.TabIndex = 600;
            this.label16.Text = "datum";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(87, 172);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(109, 16);
            this.label15.TabIndex = 599;
            this.label15.Text = "Predmet naročila";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 204);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(179, 16);
            this.label14.TabIndex = 598;
            this.label14.Text = "Opredelitev postavke - konta";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(129, 313);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(67, 16);
            this.label13.TabIndex = 597;
            this.label13.Text = "pripravil-a";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(129, 351);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 593;
            this.label9.Text = "zaposleni";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(96, 76);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 16);
            this.label2.TabIndex = 586;
            this.label2.Text = "Številka sklepa";
            // 
            // St_sklepa
            // 
            this.St_sklepa.Location = new System.Drawing.Point(209, 68);
            this.St_sklepa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.St_sklepa.Name = "St_sklepa";
            this.St_sklepa.Size = new System.Drawing.Size(113, 22);
            this.St_sklepa.TabIndex = 1;
            // 
            // opred_post_kont
            // 
            this.opred_post_kont.Location = new System.Drawing.Point(209, 204);
            this.opred_post_kont.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.opred_post_kont.Name = "opred_post_kont";
            this.opred_post_kont.Size = new System.Drawing.Size(205, 22);
            this.opred_post_kont.TabIndex = 5;
            // 
            // St_spisa
            // 
            this.St_spisa.Location = new System.Drawing.Point(209, 107);
            this.St_spisa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.St_spisa.Name = "St_spisa";
            this.St_spisa.Size = new System.Drawing.Size(113, 22);
            this.St_spisa.TabIndex = 2;
            // 
            // cbxPrip
            // 
            this.cbxPrip.FormattingEnabled = true;
            this.cbxPrip.Location = new System.Drawing.Point(209, 303);
            this.cbxPrip.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxPrip.Name = "cbxPrip";
            this.cbxPrip.Size = new System.Drawing.Size(205, 24);
            this.cbxPrip.TabIndex = 8;
            // 
            // cbxIzvPo
            // 
            this.cbxIzvPo.FormattingEnabled = true;
            this.cbxIzvPo.Location = new System.Drawing.Point(209, 270);
            this.cbxIzvPo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxIzvPo.Name = "cbxIzvPo";
            this.cbxIzvPo.Size = new System.Drawing.Size(205, 24);
            this.cbxIzvPo.TabIndex = 7;
            // 
            // cbxOdgOs
            // 
            this.cbxOdgOs.FormattingEnabled = true;
            this.cbxOdgOs.Location = new System.Drawing.Point(209, 236);
            this.cbxOdgOs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxOdgOs.Name = "cbxOdgOs";
            this.cbxOdgOs.Size = new System.Drawing.Size(205, 24);
            this.cbxOdgOs.TabIndex = 6;
            // 
            // cbxZap
            // 
            this.cbxZap.FormattingEnabled = true;
            this.cbxZap.Location = new System.Drawing.Point(209, 341);
            this.cbxZap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxZap.Name = "cbxZap";
            this.cbxZap.Size = new System.Drawing.Size(205, 24);
            this.cbxZap.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 391);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(118, 16);
            this.label3.TabIndex = 642;
            this.label3.Text = "ocenjena vrednost";
            // 
            // oc_vr
            // 
            this.oc_vr.Location = new System.Drawing.Point(211, 383);
            this.oc_vr.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.oc_vr.Name = "oc_vr";
            this.oc_vr.Size = new System.Drawing.Size(205, 22);
            this.oc_vr.TabIndex = 11;
            this.oc_vr.TextChanged += new System.EventHandler(this.oc_vr_TextChanged);
            // 
            // dtpDatum
            // 
            this.dtpDatum.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatum.Location = new System.Drawing.Point(209, 140);
            this.dtpDatum.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDatum.Name = "dtpDatum";
            this.dtpDatum.Size = new System.Drawing.Size(205, 22);
            this.dtpDatum.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(349, 510);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(145, 32);
            this.button1.TabIndex = 14;
            this.button1.Text = "Prekliči";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnPreklici_text);
            // 
            // button11
            // 
            this.button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button11.Location = new System.Drawing.Point(205, 510);
            this.button11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(136, 32);
            this.button11.TabIndex = 13;
            this.button11.Text = "Dodaj  podatke";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.btnDodaj_text);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button2.Location = new System.Drawing.Point(51, 510);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 32);
            this.button2.TabIndex = 12;
            this.button2.Text = "Ponastavi";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnPonastavi_click);
            // 
            // frmVstaviSklep
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(545, 603);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.dtpDatum);
            this.Controls.Add(this.oc_vr);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbxZap);
            this.Controls.Add(this.cbxOdgOs);
            this.Controls.Add(this.cbxIzvPo);
            this.Controls.Add(this.cbxPrip);
            this.Controls.Add(this.St_spisa);
            this.Controls.Add(this.Pred_naroc);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.izvajanje_po);
            this.Controls.Add(this.Stevilka_spisa);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.St_sklepa);
            this.Controls.Add(this.opred_post_kont);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmVstaviSklep";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vstavi sklep";
            this.Load += new System.EventHandler(this.frmVstaviSklep_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox Pred_naroc;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label izvajanje_po;
        private System.Windows.Forms.Label Stevilka_spisa;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox St_sklepa;
        private System.Windows.Forms.TextBox opred_post_kont;
        private System.Windows.Forms.TextBox St_spisa;
        private System.Windows.Forms.ComboBox cbxPrip;
        private System.Windows.Forms.ComboBox cbxIzvPo;
        private System.Windows.Forms.ComboBox cbxOdgOs;
        private System.Windows.Forms.ComboBox cbxZap;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox oc_vr;
        private System.Windows.Forms.DateTimePicker dtpDatum;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button2;
    }
}