﻿
namespace narocilnica2013
{
    partial class frmVstaviZaposlenega
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.datagridView1 = new System.Windows.Forms.DataGridView();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtbxGSM = new System.Windows.Forms.TextBox();
            this.txtbxNaziv = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtbxImePriimek = new System.Windows.Forms.TextBox();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zaposleniBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaposleniBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button9.Location = new System.Drawing.Point(12, 467);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 26);
            this.button9.TabIndex = 4;
            this.button9.Text = "Ponastavi formo";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.btnPonastavi_text);
            // 
            // button11
            // 
            this.button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button11.Location = new System.Drawing.Point(320, 467);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 26);
            this.button11.TabIndex = 5;
            this.button11.Text = "Dodaj  podatke";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.btnDodaj_text);
            // 
            // button12
            // 
            this.button12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.Location = new System.Drawing.Point(424, 467);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(101, 26);
            this.button12.TabIndex = 6;
            this.button12.Text = "Prekliči";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.btnPreklici_text);
            // 
            // datagridView1
            // 
            this.datagridView1.AllowUserToAddRows = false;
            this.datagridView1.AllowUserToDeleteRows = false;
            this.datagridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridView1.AutoGenerateColumns = false;
            this.datagridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.datagridView1.DataSource = this.zaposleniBindingSource;
            this.datagridView1.Location = new System.Drawing.Point(12, 113);
            this.datagridView1.Name = "datagridView1";
            this.datagridView1.ReadOnly = true;
            this.datagridView1.RowTemplate.Height = 25;
            this.datagridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridView1.Size = new System.Drawing.Size(513, 348);
            this.datagridView1.TabIndex = 7;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(48, 50);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(31, 13);
            this.label25.TabIndex = 570;
            this.label25.Text = "GSM";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(47, 76);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(34, 13);
            this.label24.TabIndex = 569;
            this.label24.Text = "Naziv";
            // 
            // txtbxGSM
            // 
            this.txtbxGSM.Location = new System.Drawing.Point(85, 47);
            this.txtbxGSM.Name = "txtbxGSM";
            this.txtbxGSM.Size = new System.Drawing.Size(223, 20);
            this.txtbxGSM.TabIndex = 2;
            this.txtbxGSM.TextChanged += new System.EventHandler(this.txtbxGSM_TextChanged);
            // 
            // txtbxNaziv
            // 
            this.txtbxNaziv.Location = new System.Drawing.Point(85, 73);
            this.txtbxNaziv.Name = "txtbxNaziv";
            this.txtbxNaziv.Size = new System.Drawing.Size(223, 20);
            this.txtbxNaziv.TabIndex = 3;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 13);
            this.label14.TabIndex = 566;
            this.label14.Text = "ime in priimek";
            // 
            // txtbxImePriimek
            // 
            this.txtbxImePriimek.Location = new System.Drawing.Point(85, 21);
            this.txtbxImePriimek.Name = "txtbxImePriimek";
            this.txtbxImePriimek.Size = new System.Drawing.Size(223, 20);
            this.txtbxImePriimek.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ImePriimek";
            this.dataGridViewTextBoxColumn1.HeaderText = "ImePriimek";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 200;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "GSM";
            this.dataGridViewTextBoxColumn2.HeaderText = "GSM";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Naziv";
            this.dataGridViewTextBoxColumn3.HeaderText = "Naziv";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // zaposleniBindingSource
            // 
            this.zaposleniBindingSource.DataSource = typeof(narocilnica2013.Zaposleni);
            // 
            // frmVstaviZaposlenega
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 505);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.datagridView1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtbxGSM);
            this.Controls.Add(this.txtbxNaziv);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtbxImePriimek);
            this.Name = "frmVstaviZaposlenega";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vstavi zaposlenega";
            this.Load += new System.EventHandler(this.frmVstaviZaposlenega_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zaposleniBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.DataGridView datagridView1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtbxGSM;
        private System.Windows.Forms.TextBox txtbxNaziv;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtbxImePriimek;
        private System.Windows.Forms.DataGridViewTextBoxColumn imePriimekDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn gSMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nazivDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource zaposleniBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
    }
}