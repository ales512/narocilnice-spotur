﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class frmVstaviNarocilnice : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");

        private frmPodjetja frm3;
        private frmNarocilnice forma;

        public frmVstaviNarocilnice(frmNarocilnice form)
        {
            InitializeComponent();
            form = forma;

            PodatkiComboBoxME();
            PodatkiComboBoxKontaktna();
            PodatkiComboBoxSTR();

            PodatkiComboBoxDDV();
            PodatkiComboBoxVrsta();

        }
        public frmVstaviNarocilnice()
        {
            InitializeComponent();


            PodatkiComboBoxME();
            PodatkiComboBoxKontaktna();
            PodatkiComboBoxSTR();

            PodatkiComboBoxDDV();
            PodatkiComboBoxVrsta();

        }
        public frmVstaviNarocilnice(frmPodjetja formaa)
        {
            InitializeComponent();
            formaa = frm3;

            PodatkiComboBoxME();
            PodatkiComboBoxKontaktna();
            PodatkiComboBoxSTR();

            PodatkiComboBoxDDV();
            PodatkiComboBoxVrsta();


        }

        void PodatkiComboBoxME()
        {


            string poizvedba = "select * from dbo.ME";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string me = r["ME"].ToString();
                    cbxME.Items.Add(me);
                    cbxME2.Items.Add(me);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
        void PodatkiComboBoxSTR()
        {


            string poizvedba = "select * from dbo.str_mesta";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string str = r["Str_mesto"].ToString();
                    cbxSTR_mesto.Items.Add(str);
                    cbxPostavka.Items.Add(str);


                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }


        void PodatkiComboBoxKontaktna()
        {


            string poizvedba = "select * from dbo.Zaposleni";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string imePriimek = r["imePriimek"].ToString();
                    cbxKontaktnaOseba.Items.Add(imePriimek);
                    cbxOddano.Items.Add(imePriimek);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        void PodatkiComboBoxVrsta()
        {


            string poizvedba = "select * from dbo.Vrst_nar";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string Polje1 = r["Polje1"].ToString();
                    cbxVrsta.Items.Add(Polje1);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        void PodatkiComboBoxDDV()
        {


            string poizvedba = "select * from dbo.DDV";

            SqlCommand cmd = new SqlCommand(poizvedba, connection);
            SqlDataReader r;

            try
            {
                connection.Open();
                r = cmd.ExecuteReader();
                while (r.Read())
                {
                    string ddv = r["DDV"].ToString();
                    cbxDDV.Items.Add(ddv);

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private bool KontrolaVnosnihPolj()
        {

            if (St_nar.Text == string.Empty)
            {
                MessageBox.Show("Stevilka narocilnice je obvezen");
                return false;
            }
            else if (Podjetje.Text == null)
            {
                MessageBox.Show("Podjetje je obvezen");
                return false;
            }
            else if (Naslov.Text == string.Empty)
            {
                MessageBox.Show("Naslov je obvezen");
                return false;
            }
            else if (Kraj.Text == string.Empty)
            {
                MessageBox.Show("Kraj je obvezen");
                return false;
            }

            else if (cbxVrsta.SelectedItem == null)
            {
                MessageBox.Show("Vrsta naročila je obvezen");
                return false;
            }

            else if (predmetnar.Text == string.Empty)
            {
                MessageBox.Show("Predmet narocilnice je obvezen");
                return false;
            }

            else if (cbxKontaktnaOseba.SelectedItem == null)
            {
                MessageBox.Show("Kontaktna oseba je obvezen");
                return false;
            }
            else if (cbxOddano.SelectedItem == null)
            {
                MessageBox.Show("Oddano je obvezen");
                return false;
            }
            else if (cbxSTR_mesto.SelectedItem == null)
            {
                MessageBox.Show("STR mesto je obvezen");
                return false;
            }
            else if (cbxPostavka.SelectedItem == null)
            {
                MessageBox.Show("Postavka je obvezen");
                return false;
            }


            else if (netovrednost.Text == string.Empty)
            {
                MessageBox.Show("Neto vrednost je obvezen");
                return false;
            }
            else if (brutov.Text == string.Empty)
            {
                MessageBox.Show("Bruto vrednost je obvezen");
                return false;
            }

            else if (vrednostDDV.Text == string.Empty)
            {

                MessageBox.Show("Vrednost DDV je obvezen");
                return false;
            }

            else
            {

                return true;
            }
        }

        private void frmVstaviNar2021_Load(object sender, EventArgs e)
        {
            cbxME.SelectedIndex = 0;
            cbxKontaktnaOseba.SelectedIndex = 0;

            cbxME2.SelectedIndex = 0;
            cbxOddano.SelectedIndex = 0;
            cbxSTR_mesto.SelectedIndex = 0;
            cbxDDV.SelectedIndex = 0;

            cbxVrsta.SelectedIndex = 0;

            cbxPostavka.SelectedIndex = 0;


        }


        private void btnDodaj_click(object sender, EventArgs e)
        {

            if (KontrolaVnosnihPolj() == true)
            {


                string insertQuery =
                    "INSERT INTO dbo.VseNarocilnice (St_narocilnice, Podjetje, naslov, Kraj, VrstaNarocila, Postavka, PredmetNarocilnice, kolicina1, ME, Povezava, NetoVrednost, BrutoVrednost, DDV, VrednostDDV,  PredmetNarocilnice2, Kolicina2, ME2, NetoVrednost2, BrutoVrednost2, VrednostDDV2, KontaktnaOseba, STR_mesto, Oddano, datumNarocilnice, RokDobave)VALUES('" +
                    St_nar.Text + "','" + Podjetje.Text + "', '" + Naslov.Text + "', '" +
                    Kraj.Text + "', '" + cbxVrsta.Text + "', '" + cbxPostavka.Text + "', '" + predmetnar.Text +
                    "', '" + kolicina1.Text + "', '" + cbxME.Text + "', '" + Povezava.Text + "', '" +
                    netovrednost.Text + "', '" + brutov.Text + "', '" + cbxDDV.Text + "','" + vrednostDDV.Text + "','" + pn2.Text + "', '" + kolicina2.Text + "', '" +
                    cbxME2.Text + "', '" + netodva.Text + "', '" + brutodva.Text + "', '" + vrednostDDV2.Text + "','" +
                    cbxKontaktnaOseba.Text + "', '" + cbxSTR_mesto.Text + "', '" + cbxOddano.Text + "', '" + dtpDatumNar.Value.ToString("yyyy-MM-dd") + "', '" + dtpRokDob.Value.ToString("yyyy-MM-dd") + "')";
                connection.Open();
                SqlCommand command = new SqlCommand(insertQuery, connection);

               
                try
                {

                    if (command.ExecuteNonQuery() == 1)
                    {

                        DialogResult = DialogResult.OK;

                        frmNarocilnice a = new frmNarocilnice();
                        a.Show();
                        a.iskanjePodatkov();
                        this.Close();


                    }
                    else
                    {
                        MessageBox.Show("Podatki niso vneseni...");
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }



        private void kolicina1_TextChanged_1(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(kolicina1.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                kolicina1.Text = kolicina1.Text.Remove(kolicina1.Text.Length - 1);
            }
        }

        private void kolicina2_TextChanged_1(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(kolicina2.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                kolicina2.Text = kolicina2.Text.Remove(kolicina2.Text.Length - 1);
            }
        }

        private void btnPonastavi_click(object sender, EventArgs e)
        {

            St_nar.Text = String.Empty;

            Podjetje.ResetText();
            Naslov.Text = String.Empty;
            Kraj.Text = String.Empty;

            Kraj.Text = String.Empty;



            
            predmetnar.Text = String.Empty;

            Povezava.Text = String.Empty;
            kolicina1.Text = String.Empty;
            kolicina2.Text = String.Empty;
            pn2.Text = String.Empty;


            dtpDatumNar.ResetText();

            dtpRokDob.ResetText();
            netodva.ResetText();
            brutodva.Text = String.Empty;
            netovrednost.Text = String.Empty;
            brutov.Text = String.Empty;
            vrednostDDV.Text = String.Empty;
            vrednostDDV2.Text = String.Empty;
        }


        private void btnPreklici_click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPlus_click(object sender, EventArgs e)
        {
            frmPodjetja p = new frmPodjetja(this);
            p.Show();
            this.Close();
        }

        private void btnIzracunajVrednostDDV_Click(object sender, EventArgs e)
        {
            if (netovrednost.Text == string.Empty)
            {
                MessageBox.Show("Neto vrednost je obvezen za izračun vrednost ddv!");

            }

            else
            {
                vrednostDDV.Text = ((Convert.ToDecimal(cbxDDV.Text) * Convert.ToDecimal(netovrednost.Text)) / 100).ToString();
                vrednostDDV.Text = Math.Round(double.Parse(vrednostDDV.Text), 2).ToString();
            }


        }

        private void btnBruto2_Click(object sender, EventArgs e)
        {
            if (netodva.Text == string.Empty)
            {
                MessageBox.Show("Neto vrednost 2 je obvezen za izračun bruto 2!");

            }
            else if (vrednostDDV2.Text == string.Empty)
            {
                MessageBox.Show("Vrednost DDV 2 je obvezen za izračun bruto 2!");

            }
            
            else
            {
                brutodva.Text = (Convert.ToDecimal(netodva.Text) + Convert.ToDecimal(vrednostDDV2.Text)).ToString(); // k netu prišeteješ vrednostDDV in dobiš bruto
                brutodva.Text = Math.Round(double.Parse(brutodva.Text), 2).ToString();
            }
         
           

        }

        private void vrddv2_Click(object sender, EventArgs e)
        {
            if (netodva.Text == string.Empty)
            {
                MessageBox.Show("Neto vrednost 2 je obvezen za izračun vrednost ddv 2!");
               
            }
            else
            {
                vrednostDDV2.Text = ((Convert.ToDecimal(cbxDDV.Text) * Convert.ToDecimal(netodva.Text)) / 100).ToString();
                vrednostDDV2.Text = Math.Round(double.Parse(vrednostDDV2.Text), 2).ToString();
            }

       
        }

        private void izracunajBruto_Click(object sender, EventArgs e)
        {
            if (netovrednost.Text == string.Empty)
            {
                MessageBox.Show("Neto vrednost je obvezen za izračun bruto!");

            }
            else if (vrednostDDV.Text == string.Empty)
            {
                MessageBox.Show("Vrednost DDV je obvezen za izračun bruto!");

            }
            else
            {
                brutov.Text = (Convert.ToDecimal(netovrednost.Text) + Convert.ToDecimal(vrednostDDV.Text)).ToString(); // k netu prišeteješ vrednostDDV in dobiš bruto
                brutov.Text = Math.Round(double.Parse(brutov.Text), 2).ToString();
            }
        }

        private void netovrednost_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(netovrednost.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                netovrednost.Text = netovrednost.Text.Remove(netovrednost.Text.Length - 1);
            }
        }

        private void netodva_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(netodva.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                netodva.Text = netodva.Text.Remove(netodva.Text.Length - 1);
            }
        }
    }
}
