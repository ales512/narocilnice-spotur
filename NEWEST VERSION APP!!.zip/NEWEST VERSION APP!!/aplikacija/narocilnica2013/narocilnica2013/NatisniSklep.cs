﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class NatisniSklep : Form
    {
      
        public Sklep f;
        public NatisniSklep(Sklep x)
        {
            InitializeComponent();
            x = new Sklep();
            x = f;
        }

        private void NatisniSklep_Load(object sender, EventArgs e)
        {
            if (f != null)
            {
                if (f.Odgovorna_oseba == null)
                {
                    f.Odgovorna_oseba = "/";
                }
                if (f.Zaposleni == null)
                {
                    f.Zaposleni = "/";
                }
                if (f.Direktorica == null)
                {
                    f.Direktorica = "/";
                }
                if (f.Izvajanje_po == null)
                {
                    f.Izvajanje_po = "/";
                }
                if (f.Pripravil_a == null)
                {
                    f.Pripravil_a = "/";
                }
                SklepBindingS.DataSource = f;

                Microsoft.Reporting.WinForms.ReportParameter[] p = new Microsoft.Reporting.WinForms.ReportParameter[]
                {

                new Microsoft.Reporting.WinForms.ReportParameter("St_sklepa", f.St_sklepa),
                new Microsoft.Reporting.WinForms.ReportParameter("Stevilka_spisa", f.Stevilka_spisa),
                new Microsoft.Reporting.WinForms.ReportParameter("Datum", f.Datum.ToString("dd/MM/yyyy")),
                new Microsoft.Reporting.WinForms.ReportParameter("Pred_naroc", f.Pred_naroc),
                new Microsoft.Reporting.WinForms.ReportParameter("ocenjena_vrednost", f.ocenjena_vrednost.ToString()),
                new Microsoft.Reporting.WinForms.ReportParameter("Opredelitev_postavke_konta", f.Opredelitev_postavke_konta),
                new Microsoft.Reporting.WinForms.ReportParameter("Odgovorna_oseba",f.Odgovorna_oseba),
                new Microsoft.Reporting.WinForms.ReportParameter("Izvajanje_po",f.Izvajanje_po),
                new Microsoft.Reporting.WinForms.ReportParameter("Pripravil_a",f.Pripravil_a),
                new Microsoft.Reporting.WinForms.ReportParameter("Zaposleni",f.Zaposleni),
                new Microsoft.Reporting.WinForms.ReportParameter("Direktorica","") // izbisana vrednost (fiksna) od direktorice- osebni podatki
                };
                this.reportViewer1.LocalReport.SetParameters(p);
                //this.reportViewer1.RefreshReport();

                this.reportViewer1.RefreshReport();
            }
            else
            {
                MessageBox.Show("Ni sklepa!");
                this.Close();
            }
      

        }

        private void reportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
