﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace narocilnica2013
{
    public class Sklep
    {
       

        private string _St_sklepa;

        public string St_sklepa
        {
            get { return _St_sklepa; }
            set { _St_sklepa = value; }
        }
        private string _Stevilka_spisa;

        public string Stevilka_spisa
        {
            get { return _Stevilka_spisa; }
            set { _Stevilka_spisa = value; }
        }

        private DateTime _Datum;

        public DateTime Datum
        {
            get { return _Datum; }
            set { _Datum = value; }
        }

        private string _Pred_naroc;

        public string Pred_naroc
        {
            get { return _Pred_naroc; }
            set { _Pred_naroc = value; }
        }

        private decimal _ocenjena_vrednost;

        public decimal ocenjena_vrednost
        {
            get { return _ocenjena_vrednost; }
       
            set
            {
                _ocenjena_vrednost = value;
                if (value <= 999999) //"for 6"... 6 mest pred vejico ima število
                {
                    _ocenjena_vrednost = Math.Round(value, 2); // 2 decimalki
                }

                else
                {

                    throw new InvalidOperationException();
                }
            }
        }

        private string _Opredelitev_postavke_konta;

        public string Opredelitev_postavke_konta
        {
            get { return _Opredelitev_postavke_konta; }
            set { _Opredelitev_postavke_konta = value; }
        }

        private string _Odgovorna_oseba;

        public string Odgovorna_oseba
        {
            get { return _Odgovorna_oseba; }
            set { _Odgovorna_oseba = value; }
        }

        private string _Izvajanje_po;

        public string Izvajanje_po
        {
            get { return _Izvajanje_po; }
            set { _Izvajanje_po = value; }
        }

        private string _Pripravil_a;

        public string Pripravil_a
        {
            get { return _Pripravil_a; }
            set { _Pripravil_a = value; }
        }

        private string _Zaposleni;

        public string Zaposleni
        {
            get { return _Zaposleni; }
            set { _Zaposleni = value; }
        }
        private string _Direktorica;

        public string Direktorica
        {
            get { return _Direktorica; }
            set { _Direktorica = value; }
        }

    }
}
