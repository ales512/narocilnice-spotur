﻿
namespace narocilnica2013
{
    partial class frmSklepi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtIsci = new System.Windows.Forms.TextBox();
            this.btnIsci = new System.Windows.Forms.Button();
            this.btnPonastavi = new System.Windows.Forms.Button();
            this.grvSklepi = new System.Windows.Forms.DataGridView();
            this.stsklepaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stevilkaspisaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datumDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prednarocDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ocenjenavrednostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.odgovornaosebaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.izvajanjepoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pripravilaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.zaposleniDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.direktoricaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sklepBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmiSklepi = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiDodajanjeSklepov = new System.Windows.Forms.ToolStripMenuItem();
            this.dtpDatumOd = new System.Windows.Forms.DateTimePicker();
            this.dtpDatumDo = new System.Windows.Forms.DateTimePicker();
            this.gbxFilter = new System.Windows.Forms.GroupBox();
            this.btnIsciPoDatumu = new System.Windows.Forms.Button();
            this.lblDatumDo = new System.Windows.Forms.Label();
            this.lblDatumOd = new System.Windows.Forms.Label();
            this.btnPreklici = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grvSklepi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklepBindingSource)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.gbxFilter.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtIsci
            // 
            this.txtIsci.Location = new System.Drawing.Point(9, 25);
            this.txtIsci.Name = "txtIsci";
            this.txtIsci.Size = new System.Drawing.Size(193, 20);
            this.txtIsci.TabIndex = 0;
            // 
            // btnIsci
            // 
            this.btnIsci.Location = new System.Drawing.Point(225, 25);
            this.btnIsci.Name = "btnIsci";
            this.btnIsci.Size = new System.Drawing.Size(80, 20);
            this.btnIsci.TabIndex = 1;
            this.btnIsci.Text = "Išči";
            this.btnIsci.UseVisualStyleBackColor = true;
            this.btnIsci.Click += new System.EventHandler(this.btnIsci_Click);
            // 
            // btnPonastavi
            // 
            this.btnPonastavi.Location = new System.Drawing.Point(311, 25);
            this.btnPonastavi.Name = "btnPonastavi";
            this.btnPonastavi.Size = new System.Drawing.Size(80, 20);
            this.btnPonastavi.TabIndex = 2;
            this.btnPonastavi.Text = "Ponastavi";
            this.btnPonastavi.UseVisualStyleBackColor = true;
            this.btnPonastavi.Click += new System.EventHandler(this.btnPonastavi_Click);
            // 
            // grvSklepi
            // 
            this.grvSklepi.AllowUserToAddRows = false;
            this.grvSklepi.AllowUserToDeleteRows = false;
            this.grvSklepi.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grvSklepi.AutoGenerateColumns = false;
            this.grvSklepi.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.stsklepaDataGridViewTextBoxColumn,
            this.stevilkaspisaDataGridViewTextBoxColumn,
            this.datumDataGridViewTextBoxColumn,
            this.prednarocDataGridViewTextBoxColumn,
            this.ocenjenavrednostDataGridViewTextBoxColumn,
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn,
            this.odgovornaosebaDataGridViewTextBoxColumn,
            this.izvajanjepoDataGridViewTextBoxColumn,
            this.pripravilaDataGridViewTextBoxColumn,
            this.zaposleniDataGridViewTextBoxColumn,
            this.direktoricaDataGridViewTextBoxColumn});
            this.grvSklepi.DataSource = this.sklepBindingSource;
            this.grvSklepi.Location = new System.Drawing.Point(9, 74);
            this.grvSklepi.Name = "grvSklepi";
            this.grvSklepi.ReadOnly = true;
            this.grvSklepi.RowTemplate.Height = 25;
            this.grvSklepi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grvSklepi.Size = new System.Drawing.Size(1310, 670);
            this.grvSklepi.TabIndex = 8;
       
            // 
            // stsklepaDataGridViewTextBoxColumn
            // 
            this.stsklepaDataGridViewTextBoxColumn.DataPropertyName = "St_sklepa";
            this.stsklepaDataGridViewTextBoxColumn.HeaderText = "St_sklepa";
            this.stsklepaDataGridViewTextBoxColumn.Name = "stsklepaDataGridViewTextBoxColumn";
            this.stsklepaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // stevilkaspisaDataGridViewTextBoxColumn
            // 
            this.stevilkaspisaDataGridViewTextBoxColumn.DataPropertyName = "Stevilka_spisa";
            this.stevilkaspisaDataGridViewTextBoxColumn.HeaderText = "Stevilka_spisa";
            this.stevilkaspisaDataGridViewTextBoxColumn.Name = "stevilkaspisaDataGridViewTextBoxColumn";
            this.stevilkaspisaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // datumDataGridViewTextBoxColumn
            // 
            this.datumDataGridViewTextBoxColumn.DataPropertyName = "Datum";
            this.datumDataGridViewTextBoxColumn.HeaderText = "Datum";
            this.datumDataGridViewTextBoxColumn.Name = "datumDataGridViewTextBoxColumn";
            this.datumDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // prednarocDataGridViewTextBoxColumn
            // 
            this.prednarocDataGridViewTextBoxColumn.DataPropertyName = "Pred_naroc";
            this.prednarocDataGridViewTextBoxColumn.HeaderText = "Pred_naroc";
            this.prednarocDataGridViewTextBoxColumn.Name = "prednarocDataGridViewTextBoxColumn";
            this.prednarocDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // ocenjenavrednostDataGridViewTextBoxColumn
            // 
            this.ocenjenavrednostDataGridViewTextBoxColumn.DataPropertyName = "ocenjena_vrednost";
            this.ocenjenavrednostDataGridViewTextBoxColumn.HeaderText = "ocenjena_vrednost";
            this.ocenjenavrednostDataGridViewTextBoxColumn.Name = "ocenjenavrednostDataGridViewTextBoxColumn";
            this.ocenjenavrednostDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // opredelitevpostavkekontaDataGridViewTextBoxColumn
            // 
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn.DataPropertyName = "Opredelitev_postavke_konta";
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn.HeaderText = "Opredelitev_postavke_konta";
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn.Name = "opredelitevpostavkekontaDataGridViewTextBoxColumn";
            this.opredelitevpostavkekontaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // odgovornaosebaDataGridViewTextBoxColumn
            // 
            this.odgovornaosebaDataGridViewTextBoxColumn.DataPropertyName = "Odgovorna_oseba";
            this.odgovornaosebaDataGridViewTextBoxColumn.HeaderText = "Odgovorna_oseba";
            this.odgovornaosebaDataGridViewTextBoxColumn.Name = "odgovornaosebaDataGridViewTextBoxColumn";
            this.odgovornaosebaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // izvajanjepoDataGridViewTextBoxColumn
            // 
            this.izvajanjepoDataGridViewTextBoxColumn.DataPropertyName = "Izvajanje_po";
            this.izvajanjepoDataGridViewTextBoxColumn.HeaderText = "Izvajanje_po";
            this.izvajanjepoDataGridViewTextBoxColumn.Name = "izvajanjepoDataGridViewTextBoxColumn";
            this.izvajanjepoDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // pripravilaDataGridViewTextBoxColumn
            // 
            this.pripravilaDataGridViewTextBoxColumn.DataPropertyName = "Pripravil_a";
            this.pripravilaDataGridViewTextBoxColumn.HeaderText = "Pripravil_a";
            this.pripravilaDataGridViewTextBoxColumn.Name = "pripravilaDataGridViewTextBoxColumn";
            this.pripravilaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // zaposleniDataGridViewTextBoxColumn
            // 
            this.zaposleniDataGridViewTextBoxColumn.DataPropertyName = "Zaposleni";
            this.zaposleniDataGridViewTextBoxColumn.HeaderText = "Zaposleni";
            this.zaposleniDataGridViewTextBoxColumn.Name = "zaposleniDataGridViewTextBoxColumn";
            this.zaposleniDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // direktoricaDataGridViewTextBoxColumn
            // 
            this.direktoricaDataGridViewTextBoxColumn.DataPropertyName = "Direktorica";
            this.direktoricaDataGridViewTextBoxColumn.HeaderText = "Direktorica";
            this.direktoricaDataGridViewTextBoxColumn.Name = "direktoricaDataGridViewTextBoxColumn";
            this.direktoricaDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sklepBindingSource
            // 
            this.sklepBindingSource.DataSource = typeof(narocilnica2013.Sklep);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiSklepi});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1342, 24);
            this.menuStrip1.TabIndex = 43;
            this.menuStrip1.Text = "menuStrip1";
     
            // tsmiSklepi
            // 
            this.tsmiSklepi.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiDodajanjeSklepov});
            this.tsmiSklepi.Name = "tsmiSklepi";
            this.tsmiSklepi.Size = new System.Drawing.Size(50, 20);
            this.tsmiSklepi.Text = "Sklepi";
            // 
            // tsmiDodajanjeSklepov
            // 
            this.tsmiDodajanjeSklepov.Name = "tsmiDodajanjeSklepov";
            this.tsmiDodajanjeSklepov.Size = new System.Drawing.Size(170, 22);
            this.tsmiDodajanjeSklepov.Text = "Dodajanje sklepov";
            this.tsmiDodajanjeSklepov.Click += new System.EventHandler(this.tsmiDodajanjeSklepov_Click);
            // 
            // dtpDatumOd
            // 
            this.dtpDatumOd.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatumOd.Location = new System.Drawing.Point(78, 14);
            this.dtpDatumOd.Name = "dtpDatumOd";
            this.dtpDatumOd.Size = new System.Drawing.Size(124, 20);
            this.dtpDatumOd.TabIndex = 455555;
            // 
            // dtpDatumDo
            // 
            this.dtpDatumDo.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatumDo.Location = new System.Drawing.Point(280, 14);
            this.dtpDatumDo.Name = "dtpDatumDo";
            this.dtpDatumDo.Size = new System.Drawing.Size(124, 20);
            this.dtpDatumDo.TabIndex = 43434;
            // 
            // gbxFilter
            // 
            this.gbxFilter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxFilter.Controls.Add(this.btnIsciPoDatumu);
            this.gbxFilter.Controls.Add(this.lblDatumDo);
            this.gbxFilter.Controls.Add(this.dtpDatumDo);
            this.gbxFilter.Controls.Add(this.lblDatumOd);
            this.gbxFilter.Controls.Add(this.dtpDatumOd);
            this.gbxFilter.Location = new System.Drawing.Point(792, 12);
            this.gbxFilter.Name = "gbxFilter";
            this.gbxFilter.Size = new System.Drawing.Size(527, 56);
            this.gbxFilter.TabIndex = 3;
            this.gbxFilter.TabStop = false;
            this.gbxFilter.Text = "Filter";
   
            // 
            // btnIsciPoDatumu
            // 
            this.btnIsciPoDatumu.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIsciPoDatumu.Location = new System.Drawing.Point(420, 13);
            this.btnIsciPoDatumu.Name = "btnIsciPoDatumu";
            this.btnIsciPoDatumu.Size = new System.Drawing.Size(91, 23);
            this.btnIsciPoDatumu.TabIndex = 3;
            this.btnIsciPoDatumu.Text = "Išči po datumu";
            this.btnIsciPoDatumu.UseVisualStyleBackColor = true;
            this.btnIsciPoDatumu.Click += new System.EventHandler(this.btnIsciPoDatumu_Click);
            // 
            // lblDatumDo
            // 
            this.lblDatumDo.AutoSize = true;
            this.lblDatumDo.Location = new System.Drawing.Point(218, 17);
            this.lblDatumDo.Name = "lblDatumDo";
            this.lblDatumDo.Size = new System.Drawing.Size(56, 13);
            this.lblDatumDo.TabIndex = 46;
            this.lblDatumDo.Text = "Datum do:";
            // 
            // lblDatumOd
            // 
            this.lblDatumOd.AutoSize = true;
            this.lblDatumOd.Location = new System.Drawing.Point(18, 17);
            this.lblDatumOd.Name = "lblDatumOd";
            this.lblDatumOd.Size = new System.Drawing.Size(56, 13);
            this.lblDatumOd.TabIndex = 45;
            this.lblDatumOd.Text = "Datum od:";
            // 
            // btnPreklici
            // 
            this.btnPreklici.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreklici.BackColor = System.Drawing.SystemColors.Highlight;
            this.btnPreklici.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPreklici.Location = new System.Drawing.Point(1197, 750);
            this.btnPreklici.Name = "btnPreklici";
            this.btnPreklici.Size = new System.Drawing.Size(122, 23);
            this.btnPreklici.TabIndex = 4;
            this.btnPreklici.Text = "Prekliči";
            this.btnPreklici.UseVisualStyleBackColor = false;
            this.btnPreklici.Click += new System.EventHandler(this.btnPreklici_Click);
            // 
            // frmSklepi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1342, 781);
            this.Controls.Add(this.btnPreklici);
            this.Controls.Add(this.gbxFilter);
            this.Controls.Add(this.txtIsci);
            this.Controls.Add(this.btnIsci);
            this.Controls.Add(this.btnPonastavi);
            this.Controls.Add(this.grvSklepi);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmSklepi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sklepi";
            this.Load += new System.EventHandler(this.frmSklepi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grvSklepi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sklepBindingSource)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.gbxFilter.ResumeLayout(false);
            this.gbxFilter.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtIsci;
        private System.Windows.Forms.Button btnIsci;
        private System.Windows.Forms.Button btnPonastavi;
        private System.Windows.Forms.DataGridView grvSklepi;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiSklepi;
        private System.Windows.Forms.ToolStripMenuItem tsmiDodajanjeSklepov;
        private System.Windows.Forms.DataGridViewTextBoxColumn stsklepaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stevilkaspisaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn datumDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prednarocDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ocenjenavrednostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn opredelitevpostavkekontaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn odgovornaosebaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn izvajanjepoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pripravilaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn zaposleniDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn direktoricaDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource sklepBindingSource;
        private System.Windows.Forms.DateTimePicker dtpDatumOd;
        private System.Windows.Forms.DateTimePicker dtpDatumDo;
        private System.Windows.Forms.GroupBox gbxFilter;
        private System.Windows.Forms.Button btnIsciPoDatumu;
        private System.Windows.Forms.Label lblDatumDo;
        private System.Windows.Forms.Label lblDatumOd;
        private System.Windows.Forms.Button btnPreklici;
    }
}