﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Dapper;
using MySql.Data.MySqlClient;

namespace narocilnica2013
{
    public partial class frmVstaviZaposlenega : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");
        private frmNarocilnice frmNarocilnice;

        public frmVstaviZaposlenega(frmNarocilnice frmNarocilnice)
        {
            InitializeComponent();
            this.frmNarocilnice = frmNarocilnice;
        }
                      
        public void searchData()
        {
            string query = "SELECT ImePriimek, GSM, Naziv FROM dbo.Zaposleni";

            zaposleniBindingSource.DataSource = connection.Query<Zaposleni>(query, commandType: CommandType.Text).ToList();


        }
        private void frmVstaviZaposlenega_Load(object sender, EventArgs e)
        {
             searchData();
        }

        private bool KontrolaVnosnihPolj()
        {
            if (txtbxImePriimek.Text == string.Empty)
            {
                MessageBox.Show("Ime in priimek je obvezen");
                return false;
            }
            else if (txtbxGSM.Text == string.Empty)
            {
                MessageBox.Show("GSM je obvezen");
                return false;
            }

            else if (txtbxNaziv.Text == string.Empty)
            {
                MessageBox.Show("Naziv je obvezen");
                return false;
            }

            else
            {
                return true;
            }
        }

        private void btnPreklici_text(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDodaj_text(object sender, EventArgs e)
        {
            if (KontrolaVnosnihPolj() == true)
            {
                string insertQuery = "INSERT INTO dbo.Zaposleni (ImePriimek, GSM, Naziv)VALUES('" + txtbxImePriimek.Text +
                                     "','" +
                                     txtbxGSM.Text + "','" + txtbxNaziv.Text + "')";
                connection.Open();
                SqlCommand command = new SqlCommand(insertQuery, connection);

                try
                {
                    if (command.ExecuteNonQuery() == 1)
                    {

                        DialogResult = DialogResult.OK;


                    }
                    else
                    {
                        MessageBox.Show("Podatki niso vneseni...");
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
               finally
                {
                    connection.Close();
                }
            }
        }

        private void txtbxGSM_TextChanged(object sender, EventArgs e)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(txtbxGSM.Text, "[^0-9.]"))
            {
                MessageBox.Show("Prosim, vnesi le števila!");
                txtbxGSM.Text = txtbxGSM.Text.Remove(txtbxGSM.Text.Length - 1);
            }
        }

        private void btnPonastavi_text(object sender, EventArgs e)
        {
            txtbxImePriimek.Text = String.Empty;
            txtbxGSM.Text = String.Empty;
            txtbxNaziv.Text = String.Empty;
        }
    }
}
