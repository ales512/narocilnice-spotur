﻿using Dapper;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{

    public partial class frmVstaviPodjetje : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");

        private frmNarocilnice frmNarocilnice;

       

        public frmVstaviPodjetje(frmNarocilnice frmNarocilnice)
        {
            InitializeComponent();
            this.frmNarocilnice = frmNarocilnice;
        }

        private void frmVstaviPodjetje_Load(object sender, EventArgs e)
        {
            searchData();
        }

        private void btnPreklici_text(object sender, EventArgs e)
        {
            this.Close();
           
        }
        public void searchData()
        {

            string query = "SELECT Podjetje, naslov, Kraj FROM  dbo.Dobavitelji";
            
            dobaviteljiBindingSource.DataSource = connection.Query<Podjetja>(query, commandType: CommandType.Text).ToList();

        }
        private bool KontrolaVnosnihPolj()
        {
            if (txtbxPodjetje.Text == string.Empty)
            {
                MessageBox.Show("Podjetje je obvezen");
                return false;
            }
            else if (txtbxNaslov.Text == string.Empty)
            {
                MessageBox.Show("Naslov je obvezen");
                return false;
            }
            else if (txtbxKraj.Text == string.Empty)
            {
                MessageBox.Show("Kraj je obvezen");
                return false;
            }

            else
            {
                return true;
            }
        }

        private void btnDodaj_text(object sender, EventArgs e)
        {

            if (KontrolaVnosnihPolj() == true)
            {
                string insertQuery = "INSERT INTO dbo.Dobavitelji (Podjetje, naslov, Kraj)VALUES('" + txtbxPodjetje.Text +
                                     "','" +
                                     txtbxNaslov.Text + "','" + txtbxKraj.Text + "')";
                connection.Open();
                SqlCommand command = new SqlCommand(insertQuery, connection);

                try
                {
                    if (command.ExecuteNonQuery() == 1)
                    {

                        DialogResult = DialogResult.OK;
                        


                    }
                    else
                    {
                        MessageBox.Show("Podatki niso vneseni...");
                    }


                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }
        }


        private void btnPonastavi_click(object sender, EventArgs e)
        {
            txtbxPodjetje.Text = String.Empty;
            txtbxKraj.Text = String.Empty;
            txtbxNaslov.Text = String.Empty;
        }

      
    }
}
