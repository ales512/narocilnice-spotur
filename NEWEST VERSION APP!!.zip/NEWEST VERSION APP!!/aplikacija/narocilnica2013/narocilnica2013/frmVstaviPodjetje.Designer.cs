﻿
namespace narocilnica2013
{
    partial class frmVstaviPodjetje
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtbxNaslov = new System.Windows.Forms.TextBox();
            this.txtbxKraj = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtbxPodjetje = new System.Windows.Forms.TextBox();
            this.datagridView1 = new System.Windows.Forms.DataGridView();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dobaviteljiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dobaviteljiBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(14, 50);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 13);
            this.label25.TabIndex = 514;
            this.label25.Text = "Naslov";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(29, 76);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(25, 13);
            this.label24.TabIndex = 513;
            this.label24.Text = "Kraj";
            // 
            // txtbxNaslov
            // 
            this.txtbxNaslov.Location = new System.Drawing.Point(72, 47);
            this.txtbxNaslov.Name = "txtbxNaslov";
            this.txtbxNaslov.Size = new System.Drawing.Size(223, 20);
            this.txtbxNaslov.TabIndex = 1;
            // 
            // txtbxKraj
            // 
            this.txtbxKraj.Location = new System.Drawing.Point(72, 73);
            this.txtbxKraj.Name = "txtbxKraj";
            this.txtbxKraj.Size = new System.Drawing.Size(223, 20);
            this.txtbxKraj.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 24);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 510;
            this.label14.Text = "Podjetje";
            // 
            // txtbxPodjetje
            // 
            this.txtbxPodjetje.Location = new System.Drawing.Point(72, 21);
            this.txtbxPodjetje.Name = "txtbxPodjetje";
            this.txtbxPodjetje.Size = new System.Drawing.Size(223, 20);
            this.txtbxPodjetje.TabIndex = 0;
            // 
            // datagridView1
            // 
            this.datagridView1.AllowUserToAddRows = false;
            this.datagridView1.AllowUserToDeleteRows = false;
            this.datagridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.datagridView1.AutoGenerateColumns = false;
            this.datagridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6});
            this.datagridView1.DataSource = this.dobaviteljiBindingSource;
            this.datagridView1.Location = new System.Drawing.Point(12, 113);
            this.datagridView1.Name = "datagridView1";
            this.datagridView1.ReadOnly = true;
            this.datagridView1.RowTemplate.Height = 25;
            this.datagridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.datagridView1.Size = new System.Drawing.Size(513, 348);
            this.datagridView1.TabIndex = 6;
            // 
            // button12
            // 
            this.button12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button12.Location = new System.Drawing.Point(424, 467);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(101, 26);
            this.button12.TabIndex = 5;
            this.button12.Text = "Prekliči";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.btnPreklici_text);
            // 
            // button11
            // 
            this.button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button11.Location = new System.Drawing.Point(320, 467);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 26);
            this.button11.TabIndex = 4;
            this.button11.Text = "Dodaj  podatke";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.btnDodaj_text);
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button9.Location = new System.Drawing.Point(12, 467);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(101, 26);
            this.button9.TabIndex = 3;
            this.button9.Text = "Ponastavi formo";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.btnPonastavi_click);
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Podjetje";
            this.dataGridViewTextBoxColumn4.HeaderText = "Podjetje";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 200;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Naslov";
            this.dataGridViewTextBoxColumn5.HeaderText = "Naslov";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Kraj";
            this.dataGridViewTextBoxColumn6.HeaderText = "Kraj";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dobaviteljiBindingSource
            // 
            this.dobaviteljiBindingSource.DataSource = typeof(narocilnica2013.Podjetja);
            // 
            // frmVstaviPodjetje
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(537, 505);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.datagridView1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txtbxNaslov);
            this.Controls.Add(this.txtbxKraj);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.txtbxPodjetje);
            this.Name = "frmVstaviPodjetje";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "dodaj Podjetje";
            this.Load += new System.EventHandler(this.frmVstaviPodjetje_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dobaviteljiBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtbxNaslov;
        private System.Windows.Forms.TextBox txtbxKraj;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtbxPodjetje;
        private System.Windows.Forms.DataGridViewTextBoxColumn krajDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn naslovDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn podjetjeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView datagridView1;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource dobaviteljiBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
    }
}