﻿using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class frmSklepi : Form
    {
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");

        public frmSklepi(frmNarocilnice frmNarocilnice)
        {
            InitializeComponent();
        }

        private void frmSklepi_Load(object sender, EventArgs e)
        {
            string valueToSearch = txtIsci.Text.ToString();
            searchData(valueToSearch);
        }

        private void tsmiDodajanjeSklepov_Click(object sender, EventArgs e)
        {
            frmVstaviSklep frmVstaviSklep = new frmVstaviSklep();
            frmVstaviSklep.ShowDialog();
        }

        private void searchData(string valueToSearch)
        {
            string query =
                "SELECT St_sklepa, Stevilka_spisa, Pred_naroc, ocenjena_vrednost, Opredelitev_postavke_konta, Odgovorna_oseba, Izvajanje_po, Pripravil_a, Zaposleni, Direktorica, Datum FROM dbo.vsiSklepi WHERE Datum like '%" +
                valueToSearch + "%' OR Pred_naroc like '%" + valueToSearch + "%' OR ocenjena_vrednost like '%" +
                valueToSearch + "%' OR Odgovorna_oseba like '%" + valueToSearch + "%' OR Izvajanje_po like '%" +
                valueToSearch + "%' OR Pripravil_a like '%" + valueToSearch + "%' OR Zaposleni like '%" + valueToSearch + "%' ORDER BY Datum DESC";

            sklepBindingSource.DataSource = connection.Query<Sklep>(query, commandType: CommandType.Text).ToList();
        }

        private void searchByDateFromDateTo(DateTime datumOd, DateTime datumDo)
        {
            string query =
                "SELECT St_sklepa, Stevilka_spisa, Pred_naroc, ocenjena_vrednost, Opredelitev_postavke_konta, Odgovorna_oseba, Izvajanje_po, Pripravil_a, Zaposleni, Direktorica, Datum FROM dbo.vsiSklepi WHERE Datum BETWEEN '" + datumOd.Date.ToString("yyyy-MM-dd") + "' AND '" + datumDo.Date.ToString("yyyy-MM-dd") + "' ORDER BY Datum DESC";

            sklepBindingSource.DataSource = connection.Query<Sklep>(query, commandType: CommandType.Text).ToList();
        }

        private void btnIsci_Click(object sender, EventArgs e)
        {
            string valueToSearch = txtIsci.Text.ToString();
            searchData(valueToSearch);
        }

        private void btnIsciPoDatumu_Click(object sender, EventArgs e)
        {
            if (dtpDatumOd.Value.Date > dtpDatumDo.Value.Date)
            {
                MessageBox.Show("Datum od ne more biti večji od datuma do.", "Obvestilo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; 
            }
            searchByDateFromDateTo(dtpDatumOd.Value.Date, dtpDatumDo.Value.Date);
        }

        private void btnPonastavi_Click(object sender, EventArgs e)
        {
            txtIsci.Text = string.Empty;
        }

        private void btnPreklici_Click(object sender, EventArgs e)
        {
            this.Close();

        }

    }
}
