﻿using Dapper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace narocilnica2013
{
    public partial class frmNarocilnice : Form
    {// datasource (imeracunalnika) je izbrisan, saj nemorem podati tega podatka javnosti
        SqlConnection connection = new SqlConnection(@"Data Source=\SQLEXPRESS;Initial Catalog = 'narocilnice'; Integrated Security=True;");
       
        private frmVstaviPodjetje _frm;
        private frmVstaviNarocilnice _forma;
        private frmVstaviSklep x;

        public frmNarocilnice(frmVstaviPodjetje f)
        {
            InitializeComponent();
            _frm = f;
        }

        public frmNarocilnice(frmVstaviNarocilnice f)
        {
            InitializeComponent();
            _forma = f;
        }

        public frmNarocilnice()
        { 
            InitializeComponent();
        }

        public void searchData(string valueToSearch)
        {
            string query = "SELECT Zap_st, St_narocilnice, Podjetje, naslov, Kraj, VrstaNarocila, Postavka, PredmetNarocilnice," +
                "kolicina1, ME, Povezava, NetoVrednost, BrutoVrednost, DDV, VrednostDDV, PredmetNarocilnice2, Kolicina2, ME2, NetoVrednost2, BrutoVrednost2, DDV2, VrednostDDV2, KontaktnaOseba, " +
                "STR_mesto, Oddano, datumNarocilnice, RokDobave FROM dbo.VseNarocilnice WHERE Podjetje like '%" + valueToSearch + "%' OR naslov like '%" + valueToSearch + 
                "%' OR Kraj like '%" + valueToSearch + "%' OR Postavka like '%" + valueToSearch + "%' OR PredmetNarocilnice like '%"
                + valueToSearch + "%' OR KontaktnaOseba like '%" + valueToSearch + "%' OR Oddano like '%" + valueToSearch + "%'" +
                " OR datumNarocilnice like '%" + valueToSearch + "%'  OR NetoVrednost like '%" + valueToSearch + "%' " +
                " OR BrutoVrednost like '%" + valueToSearch + "%' OR PredmetNarocilnice2 like '%"
                + valueToSearch + "%' OR NetoVrednost2 like '%" + valueToSearch + "%'  OR BrutoVrednost2 like '%"
                + valueToSearch + "%' OR DDV like '%"+ valueToSearch + "%' OR Rokdobave like '%" + valueToSearch + "%' ORDER BY datumNarocilnice DESC";
            narocilnicaBindingSource.DataSource = connection.Query<Narocilnica>(query, commandType: CommandType.Text).ToList();

         
        }
        public void iskanjePodatkov() 
        {
            string query = "SELECT Zap_st, St_narocilnice, Podjetje, naslov, Kraj, VrstaNarocila, Postavka, PredmetNarocilnice," +
                "kolicina1, ME, Povezava, NetoVrednost, BrutoVrednost, PredmetNarocilnice2, Kolicina2, ME2, NetoVrednost2, BrutoVrednost2, KontaktnaOseba, " +
                "STR_mesto, Oddano, datumNarocilnice, RokDobave FROM dbo.VseNarocilnice";



            narocilnicaBindingSource.DataSource = connection.Query<Narocilnica>(query, commandType: CommandType.Text).ToList();


        }


        private void frmVseNarocilnice_Load(object sender, EventArgs e)
        {
            string valueToSearch = textBox1.Text.ToString();
            searchData(valueToSearch);

           
        }

        public void btnIsci_Click(object sender, EventArgs e)
        {
            string valueToSearch = textBox1.Text.ToString();
            searchData(valueToSearch);
            
        }

        private void btnPonastavi_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = string.Empty;
        }

        private void tsmiDodajanjeNarocilnic_Click_1(object sender, EventArgs e)
        {
            
            frmVstaviNarocilnice frm = new frmVstaviNarocilnice(this);
          
            DialogResult dialogResult = frm.ShowDialog();
            
            if (dialogResult == DialogResult.OK)
            {
                string valueToSearch = textBox1.Text.ToString();
                searchData(valueToSearch);
            }
           
        }

        private void btnNatisniSklep_click(object sender, EventArgs e)
        {
            Sklep a = sklepBindingSource.Current as Sklep;
            List<Sklep> s = new List<Sklep>();
            string query =
                "SELECT St_sklepa, Stevilka_spisa, Pred_naroc, ocenjena_vrednost, Opredelitev_postavke_konta, Odgovorna_oseba, Izvajanje_po, Pripravil_a, Zaposleni, Direktorica, Datum FROM dbo.vsiSklepi";

            s = connection.Query<Sklep>(query, commandType: CommandType.Text).ToList();


            NatisniSklep natisni = new NatisniSklep(a);
            natisni.f = a;
            natisni.ShowDialog();

        }

        private void btnNatisniNarocilnico_click(object sender, EventArgs e)
        {

           
            Narocilnica xy = narocilnicaBindingSource.Current as Narocilnica;
            List<Narocilnica> nar2021 = new List<Narocilnica>();
            string query = "SELECT Zap_st, St_narocilnice, Podjetje, naslov, Kraj, VrstaNarocila, Postavka, PredmetNarocilnice," +
                "kolicina1, ME, Povezava, NetoVrednost, BrutoVrednost, PredmetNarocilnice2, Kolicina2, ME2, NetoVrednost2, BrutoVrednost2, KontaktnaOseba, " +
                "STR_mesto, Oddano, datumNarocilnice, RokDobave FROM dbo.VseNarocilnice";


            nar2021 = connection.Query<Narocilnica>(query, commandType: CommandType.Text).ToList();

            Natisni natisni = new Natisni(xy);
            natisni.u = xy;
            natisni.ShowDialog();
        }

        private void btnPreklici_click(object sender, EventArgs e)
        {
            this.Close();


        }
        
        private void datagrid_selectionchanged(object sender, EventArgs e)
        {
           
            if (dataGridView1.Focused) 
            {
                string narocilnica = string.Empty;
                narocilnica = dataGridView1.CurrentRow.Cells[0].Value.ToString(); 
                string query =
                        "SELECT St_sklepa, Stevilka_spisa, Pred_naroc, ocenjena_vrednost, Opredelitev_postavke_konta, Odgovorna_oseba, Izvajanje_po, Pripravil_a, Zaposleni, Direktorica, Datum FROM dbo.vsiSklepi WHERE St_sklepa = '" + narocilnica + "'";
                sklepBindingSource.DataSource = connection.Query<Sklep>(query, commandType: CommandType.Text).ToList();
            }
        }

        private void podjetjeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVstaviPodjetje f = new frmVstaviPodjetje(this);
            f.ShowDialog();
        }

        private void zaposleniToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmVstaviZaposlenega f = new frmVstaviZaposlenega(this);
            f.ShowDialog();
        }

        private void sklepiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSklepi a = new frmSklepi(this);
            a.ShowDialog();
      
        }

        private void btnIsciPoDatumu_Click(object sender, EventArgs e)
        {
            if (dtpDatumOd.Value.Date > dtpDatumDo.Value.Date)
            {
                MessageBox.Show("Datum od ne more biti večji od datuma do.", "Obvestilo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            searchByDateFromDateTo(dtpDatumOd.Value.Date, dtpDatumDo.Value.Date);
        }

        private void searchByDateFromDateTo(DateTime datumOd, DateTime datumDo)
        {
            string query =
               "SELECT Zap_st, St_narocilnice, Podjetje, naslov, Kraj, VrstaNarocila, Postavka, PredmetNarocilnice," +
                "kolicina1, ME, Povezava, NetoVrednost, BrutoVrednost, PredmetNarocilnice2, Kolicina2, ME2, NetoVrednost2, BrutoVrednost2, KontaktnaOseba, " +
                "STR_mesto, Oddano, datumNarocilnice, RokDobave FROM dbo.VseNarocilnice WHERE datumNarocilnice" +
               " BETWEEN '" + datumOd.Date.ToString("yyyy-MM-dd") + "' AND '" + datumDo.Date.ToString("yyyy-MM-dd") + "' ORDER BY datumNarocilnice DESC";

            narocilnicaBindingSource.DataSource = connection.Query<Narocilnica>(query, commandType: CommandType.Text).ToList();
        }

       

      
    }
}
