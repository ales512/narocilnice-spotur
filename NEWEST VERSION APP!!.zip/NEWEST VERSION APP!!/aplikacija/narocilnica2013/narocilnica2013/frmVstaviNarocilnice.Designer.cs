﻿
namespace narocilnica2013
{
    partial class frmVstaviNarocilnice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtpRokDob = new System.Windows.Forms.DateTimePicker();
            this.label26 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.pn2 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.netovrednost = new System.Windows.Forms.TextBox();
            this.netodva = new System.Windows.Forms.TextBox();
            this.brutodva = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.neto2 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cbxOddano = new System.Windows.Forms.ComboBox();
            this.cbxSTR_mesto = new System.Windows.Forms.ComboBox();
            this.cbxKontaktnaOseba = new System.Windows.Forms.ComboBox();
            this.cbxME2 = new System.Windows.Forms.ComboBox();
            this.cbxME = new System.Windows.Forms.ComboBox();
            this.dtpDatumNar = new System.Windows.Forms.DateTimePicker();
            this.datagridView1 = new System.Windows.Forms.DataGridView();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.kolicina2 = new System.Windows.Forms.TextBox();
            this.St_nar = new System.Windows.Forms.TextBox();
            this.predmetnar = new System.Windows.Forms.TextBox();
            this.kolicina1 = new System.Windows.Forms.TextBox();
            this.Povezava = new System.Windows.Forms.TextBox();
            this.cbxDDV = new System.Windows.Forms.ComboBox();
            this.Kraj = new System.Windows.Forms.TextBox();
            this.Naslov = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Podjetje = new System.Windows.Forms.TextBox();
            this.cbxVrsta = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cbxPostavka = new System.Windows.Forms.ComboBox();
            this.button4 = new System.Windows.Forms.Button();
            this.vrednostDDV = new System.Windows.Forms.TextBox();
            this.brutov = new System.Windows.Forms.TextBox();
            this.vrednostDDV2 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.vrddv2 = new System.Windows.Forms.Button();
            this.btnBruto2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dtpRokDob
            // 
            this.dtpRokDob.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpRokDob.Location = new System.Drawing.Point(587, 185);
            this.dtpRokDob.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpRokDob.Name = "dtpRokDob";
            this.dtpRokDob.Size = new System.Drawing.Size(205, 22);
            this.dtpRokDob.TabIndex = 20;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(107, 443);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(44, 16);
            this.label26.TabIndex = 568;
            this.label26.Text = "DDV *";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(469, 185);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(82, 16);
            this.label22.TabIndex = 564;
            this.label22.Text = "Rok dobave";
            // 
            // button9
            // 
            this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button9.Location = new System.Drawing.Point(23, 727);
            this.button9.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(135, 32);
            this.button9.TabIndex = 22;
            this.button9.Text = "Ponastavi formo";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.btnPonastavi_click);
            // 
            // button11
            // 
            this.button11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button11.Location = new System.Drawing.Point(169, 727);
            this.button11.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(135, 32);
            this.button11.TabIndex = 23;
            this.button11.Text = "Dodaj  podatke";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.btnDodaj_click);
            // 
            // pn2
            // 
            this.pn2.Location = new System.Drawing.Point(181, 512);
            this.pn2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pn2.Name = "pn2";
            this.pn2.Size = new System.Drawing.Size(205, 22);
            this.pn2.TabIndex = 11;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(11, 516);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(136, 16);
            this.label19.TabIndex = 554;
            this.label19.Text = "Predmet naročilnice 2";
            // 
            // netovrednost
            // 
            this.netovrednost.Location = new System.Drawing.Point(180, 401);
            this.netovrednost.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.netovrednost.Name = "netovrednost";
            this.netovrednost.Size = new System.Drawing.Size(205, 22);
            this.netovrednost.TabIndex = 8;
            this.netovrednost.TextChanged += new System.EventHandler(this.netovrednost_TextChanged);
            // 
            // netodva
            // 
            this.netodva.Location = new System.Drawing.Point(179, 625);
            this.netodva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.netodva.Name = "netodva";
            this.netodva.Size = new System.Drawing.Size(205, 22);
            this.netodva.TabIndex = 14;
            this.netodva.TextChanged += new System.EventHandler(this.netodva_TextChanged);
            // 
            // brutodva
            // 
            this.brutodva.Location = new System.Drawing.Point(180, 657);
            this.brutodva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.brutodva.Name = "brutodva";
            this.brutodva.ReadOnly = true;
            this.brutodva.Size = new System.Drawing.Size(205, 22);
            this.brutodva.TabIndex = 15;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(44, 405);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(96, 16);
            this.label21.TabIndex = 549;
            this.label21.Text = "neto vrednost *";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(40, 480);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(100, 16);
            this.label20.TabIndex = 548;
            this.label20.Text = "bruto vrednost *";
            // 
            // neto2
            // 
            this.neto2.AutoSize = true;
            this.neto2.Location = new System.Drawing.Point(108, 629);
            this.neto2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.neto2.Name = "neto2";
            this.neto2.Size = new System.Drawing.Size(43, 16);
            this.neto2.TabIndex = 547;
            this.neto2.Text = "neto 2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(104, 661);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(47, 16);
            this.label18.TabIndex = 546;
            this.label18.Text = "bruto 2";
            // 
            // cbxOddano
            // 
            this.cbxOddano.FormattingEnabled = true;
            this.cbxOddano.Location = new System.Drawing.Point(587, 116);
            this.cbxOddano.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxOddano.Name = "cbxOddano";
            this.cbxOddano.Size = new System.Drawing.Size(205, 24);
            this.cbxOddano.TabIndex = 18;
            // 
            // cbxSTR_mesto
            // 
            this.cbxSTR_mesto.FormattingEnabled = true;
            this.cbxSTR_mesto.Location = new System.Drawing.Point(587, 74);
            this.cbxSTR_mesto.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxSTR_mesto.Name = "cbxSTR_mesto";
            this.cbxSTR_mesto.Size = new System.Drawing.Size(205, 24);
            this.cbxSTR_mesto.TabIndex = 17;
            // 
            // cbxKontaktnaOseba
            // 
            this.cbxKontaktnaOseba.FormattingEnabled = true;
            this.cbxKontaktnaOseba.Location = new System.Drawing.Point(180, 689);
            this.cbxKontaktnaOseba.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxKontaktnaOseba.Name = "cbxKontaktnaOseba";
            this.cbxKontaktnaOseba.Size = new System.Drawing.Size(205, 24);
            this.cbxKontaktnaOseba.TabIndex = 16;
            // 
            // cbxME2
            // 
            this.cbxME2.FormattingEnabled = true;
            this.cbxME2.Location = new System.Drawing.Point(180, 585);
            this.cbxME2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxME2.Name = "cbxME2";
            this.cbxME2.Size = new System.Drawing.Size(135, 24);
            this.cbxME2.TabIndex = 13;
            // 
            // cbxME
            // 
            this.cbxME.FormattingEnabled = true;
            this.cbxME.Location = new System.Drawing.Point(180, 334);
            this.cbxME.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxME.Name = "cbxME";
            this.cbxME.Size = new System.Drawing.Size(116, 24);
            this.cbxME.TabIndex = 6;
            // 
            // dtpDatumNar
            // 
            this.dtpDatumNar.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpDatumNar.Location = new System.Drawing.Point(587, 149);
            this.dtpDatumNar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.dtpDatumNar.Name = "dtpDatumNar";
            this.dtpDatumNar.Size = new System.Drawing.Size(205, 22);
            this.dtpDatumNar.TabIndex = 19;
            // 
            // datagridView1
            // 
            this.datagridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.datagridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridView1.Location = new System.Drawing.Point(23, 727);
            this.datagridView1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.datagridView1.Name = "datagridView1";
            this.datagridView1.RowHeadersWidth = 51;
            this.datagridView1.RowTemplate.Height = 25;
            this.datagridView1.Size = new System.Drawing.Size(751, 94);
            this.datagridView1.TabIndex = 539;
            this.datagridView1.Visible = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(88, 105);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(65, 16);
            this.label17.TabIndex = 538;
            this.label17.Text = "Podjetje *";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(97, 137);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 16);
            this.label16.TabIndex = 537;
            this.label16.Text = "naslov *";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(115, 169);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(38, 16);
            this.label15.TabIndex = 536;
            this.label15.Text = "Kraj *";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(53, 204);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(97, 16);
            this.label14.TabIndex = 535;
            this.label14.Text = "Vrsta naročila *";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(77, 235);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(72, 16);
            this.label13.TabIndex = 534;
            this.label13.Text = "Postavka *";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(77, 299);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(64, 16);
            this.label12.TabIndex = 533;
            this.label12.Text = "Kolicina 1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(88, 553);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 16);
            this.label11.TabIndex = 532;
            this.label11.Text = "količina 2";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(476, 78);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 16);
            this.label10.TabIndex = 531;
            this.label10.Text = "STR mesto *";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 271);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(134, 16);
            this.label9.TabIndex = 530;
            this.label9.Text = "Predmet naročilnice *";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(120, 342);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 16);
            this.label8.TabIndex = 529;
            this.label8.Text = "ME";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(77, 373);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 16);
            this.label7.TabIndex = 528;
            this.label7.Text = "Povezava";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(113, 588);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(37, 16);
            this.label6.TabIndex = 527;
            this.label6.Text = "ME 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(33, 694);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(116, 16);
            this.label5.TabIndex = 526;
            this.label5.Text = "Kontaktna oseba *";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(492, 116);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 16);
            this.label4.TabIndex = 525;
            this.label4.Text = "Oddano *";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(432, 149);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 524;
            this.label3.Text = "datum naročilnice *";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 74);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 16);
            this.label2.TabIndex = 523;
            this.label2.Text = "Številka naročilnice *";
            // 
            // kolicina2
            // 
            this.kolicina2.Location = new System.Drawing.Point(180, 544);
            this.kolicina2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.kolicina2.Name = "kolicina2";
            this.kolicina2.Size = new System.Drawing.Size(97, 22);
            this.kolicina2.TabIndex = 12;
            this.kolicina2.TextChanged += new System.EventHandler(this.kolicina2_TextChanged_1);
            // 
            // St_nar
            // 
            this.St_nar.Location = new System.Drawing.Point(179, 74);
            this.St_nar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.St_nar.Name = "St_nar";
            this.St_nar.Size = new System.Drawing.Size(133, 22);
            this.St_nar.TabIndex = 1;
            // 
            // predmetnar
            // 
            this.predmetnar.Location = new System.Drawing.Point(181, 267);
            this.predmetnar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.predmetnar.Name = "predmetnar";
            this.predmetnar.Size = new System.Drawing.Size(205, 22);
            this.predmetnar.TabIndex = 4;
            // 
            // kolicina1
            // 
            this.kolicina1.Location = new System.Drawing.Point(180, 299);
            this.kolicina1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.kolicina1.Name = "kolicina1";
            this.kolicina1.Size = new System.Drawing.Size(89, 22);
            this.kolicina1.TabIndex = 5;
            this.kolicina1.TextChanged += new System.EventHandler(this.kolicina1_TextChanged_1);
            // 
            // Povezava
            // 
            this.Povezava.Location = new System.Drawing.Point(181, 369);
            this.Povezava.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Povezava.Name = "Povezava";
            this.Povezava.Size = new System.Drawing.Size(205, 22);
            this.Povezava.TabIndex = 7;
            // 
            // cbxDDV
            // 
            this.cbxDDV.FormattingEnabled = true;
            this.cbxDDV.Location = new System.Drawing.Point(181, 439);
            this.cbxDDV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxDDV.Name = "cbxDDV";
            this.cbxDDV.Size = new System.Drawing.Size(205, 24);
            this.cbxDDV.TabIndex = 10;
            // 
            // Kraj
            // 
            this.Kraj.Location = new System.Drawing.Point(180, 169);
            this.Kraj.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Kraj.Name = "Kraj";
            this.Kraj.ReadOnly = true;
            this.Kraj.Size = new System.Drawing.Size(205, 22);
            this.Kraj.TabIndex = 572;
            // 
            // Naslov
            // 
            this.Naslov.Location = new System.Drawing.Point(180, 137);
            this.Naslov.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Naslov.Name = "Naslov";
            this.Naslov.ReadOnly = true;
            this.Naslov.Size = new System.Drawing.Size(205, 22);
            this.Naslov.TabIndex = 573;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Location = new System.Drawing.Point(312, 727);
            this.button1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(135, 32);
            this.button1.TabIndex = 24;
            this.button1.Text = "Prekliči";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnPreklici_click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(395, 100);
            this.button2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(45, 32);
            this.button2.TabIndex = 27;
            this.button2.Text = "+";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnPlus_click);
            // 
            // Podjetje
            // 
            this.Podjetje.Location = new System.Drawing.Point(180, 105);
            this.Podjetje.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Podjetje.Name = "Podjetje";
            this.Podjetje.ReadOnly = true;
            this.Podjetje.Size = new System.Drawing.Size(205, 22);
            this.Podjetje.TabIndex = 3213123;
            // 
            // cbxVrsta
            // 
            this.cbxVrsta.FormattingEnabled = true;
            this.cbxVrsta.Location = new System.Drawing.Point(181, 201);
            this.cbxVrsta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxVrsta.Name = "cbxVrsta";
            this.cbxVrsta.Size = new System.Drawing.Size(205, 24);
            this.cbxVrsta.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button3.Location = new System.Drawing.Point(455, 727);
            this.button3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(181, 32);
            this.button3.TabIndex = 25;
            this.button3.Text = "Izračunaj Vrednost DDV";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.btnIzracunajVrednostDDV_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(456, 230);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 16);
            this.label1.TabIndex = 579;
            this.label1.Text = "Vrednost DDV *";
            // 
            // cbxPostavka
            // 
            this.cbxPostavka.FormattingEnabled = true;
            this.cbxPostavka.Location = new System.Drawing.Point(181, 235);
            this.cbxPostavka.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cbxPostavka.Name = "cbxPostavka";
            this.cbxPostavka.Size = new System.Drawing.Size(205, 24);
            this.cbxPostavka.TabIndex = 3;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.Location = new System.Drawing.Point(644, 727);
            this.button4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(129, 32);
            this.button4.TabIndex = 3213126;
            this.button4.Text = "Izračunaj bruto";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.izracunajBruto_Click);
            // 
            // vrednostDDV
            // 
            this.vrednostDDV.Location = new System.Drawing.Point(587, 226);
            this.vrednostDDV.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vrednostDDV.Name = "vrednostDDV";
            this.vrednostDDV.ReadOnly = true;
            this.vrednostDDV.Size = new System.Drawing.Size(205, 22);
            this.vrednostDDV.TabIndex = 3213127;
            // 
            // brutov
            // 
            this.brutov.Location = new System.Drawing.Point(181, 476);
            this.brutov.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.brutov.Name = "brutov";
            this.brutov.ReadOnly = true;
            this.brutov.Size = new System.Drawing.Size(208, 22);
            this.brutov.TabIndex = 3213128;
            // 
            // vrednostDDV2
            // 
            this.vrednostDDV2.Location = new System.Drawing.Point(587, 262);
            this.vrednostDDV2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vrednostDDV2.Name = "vrednostDDV2";
            this.vrednostDDV2.ReadOnly = true;
            this.vrednostDDV2.Size = new System.Drawing.Size(205, 22);
            this.vrednostDDV2.TabIndex = 3213129;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(445, 267);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(106, 16);
            this.label23.TabIndex = 3213130;
            this.label23.Text = "Vrednost DDV  2";
            // 
            // vrddv2
            // 
            this.vrddv2.Location = new System.Drawing.Point(23, 767);
            this.vrddv2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.vrddv2.Name = "vrddv2";
            this.vrddv2.Size = new System.Drawing.Size(220, 32);
            this.vrddv2.TabIndex = 3213131;
            this.vrddv2.Text = "Izračunaj Vrednost DDV 2";
            this.vrddv2.UseVisualStyleBackColor = true;
            this.vrddv2.Click += new System.EventHandler(this.vrddv2_Click);
            // 
            // btnBruto2
            // 
            this.btnBruto2.Location = new System.Drawing.Point(251, 767);
            this.btnBruto2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBruto2.Name = "btnBruto2";
            this.btnBruto2.Size = new System.Drawing.Size(129, 32);
            this.btnBruto2.TabIndex = 3213132;
            this.btnBruto2.Text = "Izračunaj bruto 2";
            this.btnBruto2.UseVisualStyleBackColor = true;
            this.btnBruto2.Click += new System.EventHandler(this.btnBruto2_Click);
            // 
            // frmVstaviNarocilnice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 836);
            this.Controls.Add(this.btnBruto2);
            this.Controls.Add(this.vrddv2);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.vrednostDDV2);
            this.Controls.Add(this.brutov);
            this.Controls.Add(this.vrednostDDV);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.cbxPostavka);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.cbxVrsta);
            this.Controls.Add(this.Podjetje);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Naslov);
            this.Controls.Add(this.Kraj);
            this.Controls.Add(this.cbxDDV);
            this.Controls.Add(this.dtpRokDob);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.pn2);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.netovrednost);
            this.Controls.Add(this.netodva);
            this.Controls.Add(this.brutodva);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.neto2);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.cbxOddano);
            this.Controls.Add(this.cbxSTR_mesto);
            this.Controls.Add(this.cbxKontaktnaOseba);
            this.Controls.Add(this.cbxME2);
            this.Controls.Add(this.cbxME);
            this.Controls.Add(this.dtpDatumNar);
            this.Controls.Add(this.datagridView1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.kolicina2);
            this.Controls.Add(this.St_nar);
            this.Controls.Add(this.predmetnar);
            this.Controls.Add(this.kolicina1);
            this.Controls.Add(this.Povezava);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmVstaviNarocilnice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vstavi naročilnico";
            this.Load += new System.EventHandler(this.frmVstaviNar2021_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtpRokDob;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox pn2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox netovrednost;
        private System.Windows.Forms.TextBox netodva;
        private System.Windows.Forms.TextBox brutodva;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label neto2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cbxOddano;
        private System.Windows.Forms.ComboBox cbxSTR_mesto;
        private System.Windows.Forms.ComboBox cbxKontaktnaOseba;
        private System.Windows.Forms.ComboBox cbxME2;
        private System.Windows.Forms.ComboBox cbxME;
        private System.Windows.Forms.DateTimePicker dtpDatumNar;
        private System.Windows.Forms.DataGridView datagridView1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox kolicina2;
        private System.Windows.Forms.TextBox St_nar;
        private System.Windows.Forms.TextBox predmetnar;
        private System.Windows.Forms.TextBox kolicina1;
        private System.Windows.Forms.TextBox Povezava;
        private System.Windows.Forms.ComboBox cbxDDV;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.TextBox Kraj;
        public System.Windows.Forms.TextBox Naslov;
        public System.Windows.Forms.TextBox Podjetje;
        private System.Windows.Forms.ComboBox cbxVrsta;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbxPostavka;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox vrednostDDV;
        private System.Windows.Forms.TextBox brutov;
        private System.Windows.Forms.TextBox vrednostDDV2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button vrddv2;
        private System.Windows.Forms.Button btnBruto2;
    }
}